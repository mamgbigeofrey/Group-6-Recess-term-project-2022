#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
#include<windows.h>
#include<mysql.h>
#include<string.h>
#include<time.h>
void finish_with_error(MYSQL *conn){
fprintf(stderr,"%s\n",mysql_error(conn));
mysql_close(conn);
exit(1);
}

int main()
{
    MYSQL *conn;
    char p_code[30],fname[30],lname[30];
    MYSQL_RES *res;
    MYSQL_ROW row;
    char assignment_id[2];
    char start[BUFSIZ],stop[BUFSIZ],sql[BUFSIZ];
    char sqlquery[255];
    char *server="localhost", *user="root", *password="", *database="kcaa";
    conn= mysql_init(NULL);
    char date[20];
    time_t tm;
    time(&tm);
    printf("TODAY IS :\t%s\n\n",ctime(&tm));


    //connecting to the database
    if(!mysql_real_connect(conn,server,user,password,database,0,NULL,0)){
            //displaying an error message and exit
        printf("Failed to connect to MYSQL server %s.Error: %s\n",server,mysql_error(conn));
        exit(1);
    }else{
        //displaying success in connection if no error
        printf("\t\t\t\t\t*************** WELCOME TO KINDERCARE ACADEMIC APPLICATION SYSTEM******************\n\n");
    }

    //authenticating the pupil login

    //getting the pupil input of their code
    printf("Enter your pupil code to login:\n\n ");
    scanf("%s", p_code);
    //compairing the inputed code
    strcpy(sqlquery,"SELECT * FROM pupilregister where CODE like \'");
    strcat(sqlquery,p_code);
    strcat(sqlquery,"\'");
    //displaying error and exiting if code doesnt match any database fetch
    if (mysql_query(conn, sqlquery) != 0){
            fprintf(stderr, "Wrong login/wrong user code:%s\n",mysql_error(conn));
            main();
    }
    res = mysql_use_result(conn);
    //displaying success message and giving permisions to pupil
    if( mysql_fetch_row(res) != NULL){
        printf("You have successfully logged in:\n");
       label: puts("PLEASE SELECT AN ACTION BELOW TO EXECUTE BY ENTERING THE CORRESPONDING INTEGERS\n");
                printf("_____________________________________________\n");
                printf("\t\t---MENU---\n");
                printf("_____________________________________________\n");
                printf("1.\tVIEW ALL\n2.\tCHECK STATUS\n3.\tVIEW ASSIGNMENT\n4.\tCHECK DATES\n5.\tREQUEST ACTIVATION\n6.\tATTEMPT ASSIGNMENT\n");
                int choice;
                puts("Enter your choice to execute:\t");
                scanf("%d",&choice);
                //checking the pupil choice and performing the appropriate tasks
                mysql_free_result(res);

        if(choice==1){
                //displaying error message is exists
            if(mysql_query(conn,"SELECT * FROM assignment")!=NULL){
                    printf( "There is no record of assignment yet.%s\n",mysql_error(conn));
                    goto label;
            }
        //if success, display the details in the assignment table
            printf("Below is the list of all the assignments as of now:\n\n");
            res = mysql_use_result(conn);
            while ((row = mysql_fetch_row(res))!=0)
                 {
                 printf("ASSIGNMENT ID:%s\t\t",row[0]);
                 printf("START TIME:%s\t\t",row[5]);
                 printf("END TIME:%s\n\n",row[6]);
                 }
                 printf("\n\n");
                 mysql_free_result(res);
                 goto label;
                }


        if(choice==2){
                sprintf(sql,"SELECT * FROM pupilregister WHERE CODE = '%s' ",p_code);
                     if (mysql_query(conn, sql) !=NULL)
                     {
                     fprintf(stderr, "No pupil with such record.%s\n",mysql_error(conn));
                     exit(1);
                     }
                     printf("Below are your details:\n\n\n");
                     res = mysql_use_result(conn);
                     while ((row = mysql_fetch_row(res)) != NULL)
                     {
                     printf("\tSTATUS: 0 MEANS YOU ARE DEACTIVATED, WHILE STATUS: 1 MEANS YOU ARE ACTIVATED.\n\n");
                     printf("STATUS: %s \n", row[5]);
                    }
                     mysql_free_result(res);


                     sprintf(sql,"SELECT COUNT(*) FROM pScores WHERE pcode = '%s' ",p_code);
                     if (mysql_query(conn, sql) !=NULL)
                     {
                     fprintf(stderr, "No pupil with such record.%s\n",mysql_error(conn));
                     exit(1);
                     }
                     res = mysql_use_result(conn);
                     while ((row = mysql_fetch_row(res)) != NULL)
                     {
                     printf("You have attempted a total of : %s\tassignments \n",row[0]);
                    }
                     mysql_free_result(res);



                     sprintf(sql,"SELECT avg(score) FROM pScores WHERE pcode = '%s' ",p_code);
                     if (mysql_query(conn, sql) !=NULL)
                     {
                     fprintf(stderr, "No pupil with such record.%s\n",mysql_error(conn));
                     exit(1);
                     }
                     res = mysql_use_result(conn);
                     while ((row = mysql_fetch_row(res)) != NULL)
                     {
                     printf("Your average score for all the assignments : %f%% assignment(s) \n",atof(row[0]));
                     //float marking=row[0];
                     float missed=100 - atof(row[0]);
                     printf("The percentage missed in assignments so far attempte=%.2f%%\n",missed);
                    }
                     mysql_free_result(res);
                     goto label;


                }

         if(choice==3){
                     printf("Please enter the assignment ID to view:\t ");
                     scanf("%s", &assignment_id);
                     strcpy(sqlquery,"SELECT * FROM assignment where id like \'");
                     strcat(sqlquery,assignment_id);
                     strcat(sqlquery,"\'");
                     if (mysql_query(conn, sqlquery) != 0)
                     {
                     fprintf(stderr, "No assignment was found with the ID.%s\n",mysql_error(conn));
                     goto label;
                     }
                     printf("The details of the assignment with this ID are as follows:\n\n");
                     res = mysql_use_result(conn);
                     while ((row = mysql_fetch_row(res)) != NULL)
                     {
                     printf("ASSIGNMENT ID: %s \n", row[0]);
                     printf("ASSIGNMENT NOTE: %s \n", row[2]);
                     printf("ASSIGNMENT CHARACTERS: %s \t", row[3]);
                     printf("ASSIGNED MARKS: %s \t", row[4]);
                     printf("START TIME: %s \t", row[5]);
                     printf("END TIME: %s \n\n", row[6]);
                    }
                     mysql_free_result(res);
                     goto label;

                    }
     if(choice==4){
             printf("Input the date to start searching from in the format YEAR-MONTH-DAY e.g 2022-01-27:\n");
             scanf("%s",&start);
             printf("Input the date to stop searching at in the format YEAR-MONTH-DAY e.g 2022-01-27:\n");
             scanf("%s",&stop);
             sprintf(sql,"SELECT * FROM assignment WHERE starttime>= '%s' AND endtime<= '%s'",start,stop);
                     if (mysql_query(conn, sql) !=NULL)
                     {
                     fprintf(stderr, "No assignment was found with the specified dates dates.%s\n",mysql_error(conn));
                     exit(1);
                     }
                     printf("The details of the assignment matching your date entries are::\n");
                     printf("No assignment means none of your specified dates match an assignment date:\n\n\n");
                     res = mysql_use_result(conn);
                     while ((row = mysql_fetch_row(res)) != NULL)
                     {
                     printf("ASSIGNMENT ID: %s \t", row[0]);
                     printf("START TIME: %s \t", row[5]);
                     printf("END TIME: %s \n\n\n", row[6]);
                    }
                     mysql_free_result(res);
                     goto label;

                    }


        if(choice==5){
                 printf("Enter your firstname:\t ");
                 scanf("%s",&fname);
                 printf("Enter your last name:\t ");
                 scanf("%s",&lname);
                 strcpy(sqlquery,"INSERT INTO activation_requests (firstname,lastname,pcode)VALUES (\'");
                 strcat(sqlquery,fname);
                 strcat(sqlquery,"\', \'");
                 strcat(sqlquery,lname);
                 strcat(sqlquery,"\', \'");
                 strcat(sqlquery,p_code);
                 strcat(sqlquery,"\')");
                 if (mysql_query(conn, sqlquery) != 0)
                 {
                 fprintf(stderr, "OOOps!! Your request was unable to process. %s\n",mysql_error(conn));
                 goto label;
                 }
                 printf("Great!! Your activation request was submitted successfully.\n\n");
                // mysql_close(conn);
                goto label;
                }
        if(choice==6){
                 sprintf(sql,"SELECT STATUS FROM pupilregister WHERE CODE = '%s' ",p_code);
                     if (mysql_query(conn, sql) !=NULL)
                     {
                     fprintf(stderr, "No pupil with such record.%s\n",mysql_error(conn));
                     exit(1);
                     }
                     res = mysql_use_result(conn);
                     while ((row = mysql_fetch_row(res)) != NULL)
                     {
                         if(atof(row[0])==0){
                                 printf("You have been deactivated and so cant attempt assignment. You can send an activation request by entering option 5. \n\n");
                         goto label;

                         }
                         else printf("Please follow the following instructions to attempt the assignment.\n\n");

                    }
                     mysql_free_result(res);

               // int m;

                printf("Please enter the assignment ID to attempt:\t ");
                     scanf("%s", &assignment_id);
                     strcpy(sqlquery,"SELECT * FROM assignment where id like \'");
                     strcat(sqlquery,assignment_id);
                     strcat(sqlquery,"\'");
                     if (mysql_query(conn, sqlquery) != 0)
                     {
                     fprintf(stderr, "No assignment was found with the ID.%s\n",mysql_error(conn));
                     goto label;
                     }
                     printf("You are attempting the following characters:\n\n");
                     res = mysql_use_result(conn);
                     while ((row = mysql_fetch_row(res)) != NULL)
                     {
                     printf("ASSIGNMENT CHARACTERS: %s \t", row[3]);
                     printf("ASSIGNED MARKS: %s \t\n\n", row[4]);

                    // m=strlen(row[3]);
                    }

                     mysql_free_result(res);


                     sprintf(sql,"SELECT (endtime-starttime) from assignment where id='%s'",assignment_id);
                     if (mysql_query(conn, sql) !=NULL)
                     {
                     fprintf(stderr, "No assignment was found with the specified ID.%s\n",mysql_error(conn));
                     exit(1);
                     }
                     res = mysql_use_result(conn);
                     while ((row = mysql_fetch_row(res)) != NULL)
                     {
                     printf("This assignment expires after: %.1f hours\n",atof(row[0]));
                    }
                     mysql_free_result(res);

int m;
printf("Enter the size of the array by counting the number of characters in the assignment.\n");
scanf("%d",&m);

char exercise[m];	//Assigned exercise by the teacher
int marks[m];   //Assigned marks for each letter depending on complexity
printf("Enter the letters in the exercise\n");
for(int i=0;i<m;i++)
{
    scanf("%s",&exercise[i]);
}
printf("Enter the marks array\n");
for(int i=0;i<m;i++)
{
    scanf("%d",&marks[i]);
}
    int letterScore,sampleScore;
        letterScore = sampleScore =0;
    double x;
    double finalMark, letterMark, studentScore;
   clock_t startTime,endTime,TimeA,TimeB,TimeC,TimeD,TimeE,TimeF,TimeG,TimeH,TimeI,TimeJ,TimeK,TimeL,TimeM,TimeN,TimeO,TimeP,TimeQ,TimeR,TimeS,TimeT,TimeU,TimeV,TimeW,TimeX,TimeY,TimeZ;

 int letterA[7][4]={0,1,1,0,1,0,0,1,1,0,0,1,1,1,1,1,1,0,0,1,1,0,0,1,1,0,0,1};
 int letterB[7][4]={1,1,1,0,1,0,0,1,1,0,0,1,1,1,1,0,1,0,0,1,1,0,0,1,1,1,1,0};
 int letterC[7][4]={0,0,1,1,0,1,0,0,1,0,0,0,1,0,0,0,1,0,0,0,0,1,0,0,0,0,1,1};
 int letterD[7][4]={1,1,0,0,1,0,1,0,1,0,0,1,1,0,0,1,1,0,0,1,1,0,1,0,1,1,0,0};
 int letterE[7][4]={1,1,1,1,1,0,0,0,1,0,0,0,1,1,1,1,1,0,0,0,1,0,0,0,1,1,1,1};
 int letterF[7][4]={1,1,1,1,1,0,0,0,1,0,0,0,1,1,1,1,1,0,0,0,1,0,0,0,1,0,0,0};
 int letterG[7][4]={0,1,1,0,1,0,0,1,1,0,0,0,1,0,0,0,1,0,1,1,1,0,0,1,0,1,1,0};
 int letterH[7][4]={1,0,0,1,1,0,0,1,1,0,0,1,1,1,1,1,1,0,0,1,1,0,0,1,1,0,0,1};
 int letterI[7][4]={1,0,0,0,1,0,0,0,1,0,0,0,1,0,0,0,1,0,0,0,1,0,0,0,1,0,0,0};
 int letterJ[7][4]={0,0,0,1,0,0,0,1,0,0,0,1,0,0,0,1,1,0,0,1,1,0,0,1,0,1,1,0};
 int letterK[7][4]={1,0,0,1,1,0,1,0,1,1,0,0,1,0,0,0,1,1,0,0,1,0,1,0,1,0,0,1};
 int letterL[7][4]={1,0,0,0,1,0,0,0,1,0,0,0,1,0,0,0,1,0,0,0,1,0,0,0,1,1,1,1};
 int letterM[7][4]={1,0,0,1,1,1,1,1,1,0,0,1,1,0,0,1,1,0,0,1,1,0,0,1,1,0,0,1};
 int letterN[7][4]={1,0,0,1,1,1,0,1,1,0,0,1,1,0,0,1,1,0,0,1,1,0,1,1,1,0,0,1};
 int letterO[7][4]={0,1,1,0,1,0,0,1,1,0,0,1,1,0,0,1,1,0,0,1,1,0,0,1,0,1,1,0};
 int letterP[7][4]={1,1,1,0,1,0,0,1,1,0,0,1,1,1,1,0,1,0,0,0,1,0,0,0,1,0,0,0};
 int letterQ[7][4]={0,1,1,0,1,0,0,1,1,0,0,1,1,0,0,1,1,0,0,1,1,0,1,1,0,1,1,1};
 int letterR[7][4]={1,1,1,0,1,0,0,1,1,0,0,1,1,1,1,0,1,1,0,0,1,0,1,0,1,0,0,1};
 int letterS[7][4]={0,1,1,0,1,0,0,1,1,0,0,0,0,1,1,0,0,0,0,1,1,0,0,1,0,1,1,0};
 int letterT[7][4]={1,1,1,0,0,1,0,0,0,1,0,0,0,1,0,0,0,1,0,0,0,1,0,0,0,1,0,0};
 int letterU[7][4]={1,0,0,1,1,0,0,1,1,0,0,1,1,0,0,1,1,0,0,1,1,0,0,1,0,1,1,0};
 int letterV[7][4]={1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0};
 int letterW[7][4]={1,0,0,1,1,0,0,1,1,0,0,1,1,0,0,1,1,0,0,1,1,1,1,1,1,0,0,1};
 int letterX[7][4]={1,0,0,1,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,1,0,0,1};
 int letterY[7][4]={1,0,1,0,1,0,1,0,1,0,1,0,1,1,1,0,0,1,0,0,0,1,0,0,0,1,0,0};
 int letterZ[7][4]={1,1,1,1,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,1,1,1,1};
 int  answer[7][4];
 float A=0,B=0,C=0,D=0,E=0,F=0,G=0,H=0,I=0,J=0,K=0,L=0,M=0,N=0,O=0,P=0,Q=0,R=0,S=0,T=0,U=0,V=0,W=0,X=0,Y=0,Z=0;
 double tA=0,tB=0,tC=0,tD=0,tE=0,tF=0,tG=0,tH=0,tI=0,tJ=0,tK=0,tL=0,tM=0,tN=0,tO=0,tP=0,tQ=0,tR=0,tS=0,tT=0,tU=0,tV=0,tW=0,tX=0,tY=0,tZ=0;


printf("Use 1 or 0 to draw the letters given in the assignment\n \tPlace a 1 where the Letter plot should appear or a 0 where it shouldn't'\n\n");
    for(int k=0; k<m; k++) //Counter for the letters in the exercise
    {
        printf("\n\nSketch the letter %c\n",exercise[k]);
        printf("You have a maximum of 50 seconds to finish each exercise\n");
        printf("\n\n\tThe Expected correct pattern is\n");
if(exercise[k]=='A')
    {
    for(int i=0;i<7;i++)
    {
            for(int j=0;j<4;j++)
            {
                if(letterA[i][j] == 1)
                {
                    printf("*");
                }
                else{
                    printf(" ");
                }

            }
                printf("\n");
    }

        printf("\n\n\tIt's your turn, try it out\n");
startTime=clock();
        for(int i=0;i<7;i++)
        {
            for(int j=0;j<4;j++)
            {
                scanf("%d", &answer[i][j]);	//Accepts input from the pupil

                if(answer[i][j]== letterA[i][j])
                {
                   letterScore = letterScore + 1;	//letterScore variable is increased by one for each correct point plotted on a letter
                }
            }
TimeA=clock();
if((((double)(TimeA-startTime))/CLOCKS_PER_SEC)>50)
{
    printf("Your time has elapsed remember to follow time next time\n");
    break;
}
else
    continue;
        }
endTime=clock();
double time_taken = ((double)(endTime-startTime))/CLOCKS_PER_SEC; // in seconds
tA=time_taken;
	printf("\n\nThe drawn letter pattern is\n");
for(int i=0;i<7;i++)
{
		for(int j=0;j<4;j++)
		{
			if(answer[i][j] == 1)
			{
				printf("*");
			}
			else{
				printf(" ");
			}

		}
			printf("\n");
}
double tima=50-(((double)(TimeA-startTime))/CLOCKS_PER_SEC);
if(tima>=1)
    printf("You have finished the exercice %.1f seconds earlier\n",tima);
  printf("Correct number of points plotted are %d.",letterScore);
  A=letterMark = (letterScore/28.0)*marks[k];
  printf("\nYou have score %.2f out of %d in this exercise.",letterMark,marks[k]);
  printf("\nYou have taken %.4f seconds to complete this exercise.",time_taken);
  letterScore=0;
  }


else if(exercise[k]=='B')//PRINTING B
    {
    for(int i=0;i<7;i++)
    {
            for(int j=0;j<4;j++)
            {
                if(letterB[i][j] == 1)
                {
                    printf("*");
                }
                else{
                    printf(" ");
                }

            }
                printf("\n");
    }

        printf("\n\n\tIt's your turn, try it out\n");
startTime=clock();
        for(int i=0;i<7;i++)
        {
            for(int j=0;j<4;j++)
            {
                scanf("%d", &answer[i][j]);	//Accepts input from the pupil

                if(answer[i][j]== letterB[i][j])
                {
                    letterScore = letterScore + 1;	//letterScore variable is increased by one for each correct point plotted on a letter
                }
            }
TimeB=clock();
if((((double)(TimeB-startTime))/CLOCKS_PER_SEC)>50)
{
    printf("Your time has elapsed remember to follow time next time\n");
    break;
}
else
    continue;
        }
endTime=clock();
double time_taken = ((double)(endTime-startTime))/CLOCKS_PER_SEC; // in seconds
tB=time_taken;
	printf("\n\nThe drawn letter pattern is\n");
for(int i=0;i<7;i++)
{
		for(int j=0;j<4;j++)
		{
			if(answer[i][j] == 1)
			{
				printf("*");
			}
			else{
				printf(" ");
			}

		}
			printf("\n");
}
double timb=50-(((double)(TimeB-startTime))/CLOCKS_PER_SEC);
if(timb>=1)
    printf("You have finished the exercice %.1f seconds earlier\n",timb);
  printf("Correct number of points plotted are %d.",letterScore);
  B=letterMark = (letterScore/28.0)*marks[k];
  printf("\nYou have score %.2f out of %d in this exercise.",letterMark,marks[k]);
  printf("\nYou have taken %.4f seconds to complete this exercise.",time_taken);
  letterScore=0;
}

else if(exercise[k]=='C')//PRINTING C
    {
    for(int i=0;i<7;i++)
    {
            for(int j=0;j<4;j++)
            {
                if(letterC[i][j] == 1)
                {
                    printf("*");
                }
                else{
                    printf(" ");
                }

            }
                printf("\n");
    }

        printf("\n\n\tIt's your turn, try it out\n");
startTime=clock();
        for(int i=0;i<7;i++)
        {
            for(int j=0;j<4;j++)
            {
                scanf("%d", &answer[i][j]);	//Accepts input from the pupil

                if(answer[i][j]== letterC[i][j])
                {
                    letterScore = letterScore + 1;	//letterScore variable is increased by one for each correct point plotted on a letter
                }
            }
TimeC=clock();
if((((double)(TimeC-startTime))/CLOCKS_PER_SEC)>50)
{
    printf("Your time has elapsed remember to follow time next time\n");
    break;
}
else
    continue;
        }
endTime=clock();
double time_taken = ((double)(endTime-startTime))/CLOCKS_PER_SEC; // in seconds
tC=time_taken;
	printf("\n\nThe drawn letter pattern is\n");
for(int i=0;i<7;i++)
{
		for(int j=0;j<4;j++)
		{
			if(answer[i][j] == 1)
			{
				printf("*");
			}
			else{
				printf(" ");
			}

		}
			printf("\n");
}
double timc=50-(((double)(TimeC-startTime))/CLOCKS_PER_SEC);
if(timc>=1)
    printf("You have finished the exercice %.1f seconds earlier\n",timc);
printf("Correct number of points plotted are %d.",letterScore);
  C=letterMark = (letterScore/28.0)*marks[k];
  printf("\nYou have score %.2f out of %d in this exercise.",letterMark,marks[k]);
  printf("\nYou have taken %.4f seconds to complete this exercise.",time_taken);
  letterScore=0;
}
else if(exercise[k]=='D')//PRINTING D
    {
    for(int i=0;i<7;i++)
    {
            for(int j=0;j<4;j++)
            {
                if(letterD[i][j] == 1)
                {
                    printf("*");
                }
                else{
                    printf(" ");
                }

            }
                printf("\n");
    }

        printf("\n\n\tIt's your turn, try it out\n");
startTime=clock();
        for(int i=0;i<7;i++)
        {
            for(int j=0;j<4;j++)
            {
                scanf("%d", &answer[i][j]);	//Accepts input from the pupil

                if(answer[i][j]== letterD[i][j])
                {
                    letterScore = letterScore + 1;	//letterScore variable is increased by one for each correct point plotted on a letter
                }
            }
TimeD=clock();
if((((double)(TimeD-startTime))/CLOCKS_PER_SEC)>50)
{
    printf("Your time has elapsed remember to follow time next time\n");
    break;
}
else
    continue;
        }
endTime=clock();
double time_taken = ((double)(endTime-startTime))/CLOCKS_PER_SEC; // in seconds
tD=time_taken;
	printf("\n\nThe drawn letter pattern is\n");
for(int i=0;i<7;i++)
{
		for(int j=0;j<4;j++)
		{
			if(answer[i][j] == 1)
			{
				printf("*");
			}
			else{
				printf(" ");
			}

		}
			printf("\n");
}
double timd=50-(((double)(TimeD-startTime))/CLOCKS_PER_SEC);
if(timd>=1)
    printf("You have finished the exercice %.1f seconds earlier\n",timd);
printf("Correct number of points plotted are %d.",letterScore);
  D=letterMark = (letterScore/28.0)*marks[k];
  printf("\nYou have score %.2f out of %d in this exercise.",letterMark,marks[k]);
  printf("\nYou have taken %.4f seconds to complete this exercise.",time_taken);
  letterScore=0;
}
else if(exercise[k]=='E')//PRINTING E
    {
    for(int i=0;i<7;i++)
    {
            for(int j=0;j<4;j++)
            {
                if(letterE[i][j] == 1)
                {
                    printf("*");
                }
                else{
                    printf(" ");
                }

            }
                printf("\n");
    }

        printf("\n\n\tIt's your turn, try it out\n");
startTime=clock();
        for(int i=0;i<7;i++)
        {
            for(int j=0;j<4;j++)
            {
                scanf("%d", &answer[i][j]);	//Accepts input from the pupil

                if(answer[i][j]== letterE[i][j])
                {
                    letterScore = letterScore + 1;	//letterScore variable is increased by one for each correct point plotted on a letter
                }
            }
TimeE=clock();
if((((double)(TimeE-startTime))/CLOCKS_PER_SEC)>50)
{
    printf("Your time has elapsed remember to follow time next time\n");
    break;
}
else
    continue;
        }
endTime=clock();
double time_taken = ((double)(endTime-startTime))/CLOCKS_PER_SEC; // in seconds
tE=time_taken;
	printf("\n\nThe drawn letter pattern is\n");
for(int i=0;i<7;i++)
{
		for(int j=0;j<4;j++)
		{
			if(answer[i][j] == 1)
			{
				printf("*");
			}
			else{
				printf(" ");
			}

		}
			printf("\n");
}
double time=50-(((double)(TimeE-startTime))/CLOCKS_PER_SEC);
if(time>=1)
    printf("You have finished the exercice %.1f seconds earlier\n",time);
printf("Correct number of points plotted are %d.",letterScore);
  E=letterMark = (letterScore/28.0)*marks[k];
  printf("\nYou have score %.2f out of %d in this exercise.",letterMark,marks[k]);
  printf("\nYou have taken %.4f seconds to complete this exercise.",time_taken);
  letterScore=0;
}
else if(exercise[k]=='F')//PRINTING F
    {
    for(int i=0;i<7;i++)
    {
            for(int j=0;j<4;j++)
            {
                if(letterF[i][j] == 1)
                {
                    printf("*");
                }
                else{
                    printf(" ");
                }

            }
                printf("\n");
    }

        printf("\n\n\tIt's your turn, try it out\n");
startTime=clock();
        for(int i=0;i<7;i++)
        {
            for(int j=0;j<4;j++)
            {
                scanf("%d", &answer[i][j]);	//Accepts input from the pupil

                if(answer[i][j]== letterF[i][j])
                {
                    letterScore = letterScore + 1;	//letterScore variable is increased by one for each correct point plotted on a letter
                }
            }
TimeF=clock();
if((((double)(TimeF-startTime))/CLOCKS_PER_SEC)>50)
{
    printf("Your time has elapsed remember to follow time next time\n");
    break;
}
else
    continue;
        }
endTime=clock();
double time_taken = ((double)(endTime-startTime))/CLOCKS_PER_SEC; // in seconds
tF=time_taken;
	printf("\n\nThe drawn letter pattern is\n");
for(int i=0;i<7;i++)
{
		for(int j=0;j<4;j++)
		{
			if(answer[i][j] == 1)
			{
				printf("*");
			}
			else{
				printf(" ");
			}

		}
			printf("\n");
}
double timf=50-(((double)(TimeF-startTime))/CLOCKS_PER_SEC);
if(timf>=1)
    printf("You have finished the exercice %.1f seconds earlier\n",timf);
printf("Correct number of points plotted are %d.",letterScore);
  F=letterMark = (letterScore/28.0)*marks[k];
  printf("\nYou have score %.2f out of %d in this exercise.",letterMark,marks[k]);
  printf("\nYou have taken %.4f seconds to complete this exercise.",time_taken);
  letterScore=0;
}
else if(exercise[k]=='G')//PRINTING G
    {
    for(int i=0;i<7;i++)
    {
            for(int j=0;j<4;j++)
            {
                if(letterG[i][j] == 1)
                {
                    printf("*");
                }
                else{
                    printf(" ");
                }

            }
                printf("\n");
    }

        printf("\n\n\tIt's your turn, try it out\n");
startTime=clock();
        for(int i=0;i<7;i++)
        {
            for(int j=0;j<4;j++)
            {
                scanf("%d", &answer[i][j]);	//Accepts input from the pupil

                if(answer[i][j]== letterG[i][j])
                {
                    letterScore = letterScore + 1;	//letterScore variable is increased by one for each correct point plotted on a letter
                }
            }
TimeG=clock();
if((((double)(TimeG-startTime))/CLOCKS_PER_SEC)>50)
{
    printf("Your time has elapsed remember to follow time next time\n");
    break;
}
else
    continue;
        }
endTime=clock();
double time_taken = ((double)(endTime-startTime))/CLOCKS_PER_SEC; // in seconds
tG=time_taken;
	printf("\n\nThe drawn letter pattern is\n");
for(int i=0;i<7;i++)
{
		for(int j=0;j<4;j++)
		{
			if(answer[i][j] == 1)
			{
				printf("*");
			}
			else{
				printf(" ");
			}

		}
			printf("\n");
}
double timg=50-(((double)(TimeG-startTime))/CLOCKS_PER_SEC);
if(timg>=1)
    printf("You have finished the exercice %.1f seconds earlier\n",timg);
printf("Correct number of points plotted are %d.",letterScore);
  G=letterMark = (letterScore/28.0)*marks[k];
  printf("\nYou have score %.2f out of %d in this exercise.",letterMark,marks[k]);
  printf("\nYou have taken %.4f seconds to complete this exercise.",time_taken);
  letterScore=0;
}
else if(exercise[k]=='H')//PRINTING H
    {
    for(int i=0;i<7;i++)
    {
            for(int j=0;j<4;j++)
            {
                if(letterH[i][j] == 1)
                {
                    printf("*");
                }
                else{
                    printf(" ");
                }

            }
                printf("\n");
    }

        printf("\n\n\tIt's your turn, try it out\n");
startTime=clock;
        for(int i=0;i<7;i++)
        {
            for(int j=0;j<4;j++)
            {
                scanf("%d", &answer[i][j]);	//Accepts input from the pupil

                if(answer[i][j]== letterH[i][j])
                {
                    letterScore = letterScore + 1;	//letterScore variable is increased by one for each correct point plotted on a letter
                }
            }
TimeH=clock();
if((((double)(TimeH-startTime))/CLOCKS_PER_SEC)>50)
{
    printf("Your time has elapsed remember to follow time next time\n");
    break;
}
else
    continue;
        }
endTime=clock();
double time_taken = ((double)(endTime-startTime))/CLOCKS_PER_SEC; // in seconds
tH=time_taken;
	printf("\n\nThe drawn letter pattern is\n");
for(int i=0;i<7;i++)
{
		for(int j=0;j<4;j++)
		{
			if(answer[i][j] == 1)
			{
				printf("*");
			}
			else{
				printf(" ");
			}

		}
			printf("\n");
}
double timh=50-(((double)(TimeH-startTime))/CLOCKS_PER_SEC);
if(timh>=1)
    printf("You have finished the exercice %.1f seconds earlier\n",timh);
printf("Correct number of points plotted are %d.",letterScore);
  H=letterMark = (letterScore/28.0)*marks[k];
  printf("\nYou have score %.2f out of %d in this exercise.",letterMark,marks[k]);
  printf("\nYou have taken %.4f seconds to complete this exercise.",time_taken);
  letterScore=0;
}
else if(exercise[k]=='I')//PRINTING I
    {
    for(int i=0;i<7;i++)
    {
            for(int j=0;j<4;j++)
            {
                if(letterI[i][j] == 1)
                {
                    printf("*");
                }
                else{
                    printf(" ");
                }

            }
                printf("\n");
    }

        printf("\n\n\tIt's your turn, try it out\n");
startTime=clock();
        for(int i=0;i<7;i++)
        {
            for(int j=0;j<4;j++)
            {
                scanf("%d", &answer[i][j]);	//Accepts input from the pupil

                if(answer[i][j]== letterI[i][j])
                {
                    letterScore = letterScore + 1;	//letterScore variable is increased by one for each correct point plotted on a letter
                }
            }
TimeI=clock();
if((((double)(TimeI-startTime))/CLOCKS_PER_SEC)>50)
{
    printf("Your time has elapsed remember to follow time next time\n");
    break;
}
else
    continue;
        }
endTime=clock();
double time_taken = ((double)(endTime-startTime))/CLOCKS_PER_SEC; // in seconds
tI=time_taken;
	printf("\n\nThe drawn letter pattern is\n");
for(int i=0;i<7;i++)
{
		for(int j=0;j<4;j++)
		{
			if(answer[i][j] == 1)
			{
				printf("*");
			}
			else{
				printf(" ");
			}

		}
			printf("\n");
}
double timi=50-(((double)(TimeI-startTime))/CLOCKS_PER_SEC);
if(timi>=1)
    printf("You have finished the exercice %.1f seconds earlier\n",timi);
printf("Correct number of points plotted are %d.",letterScore);
  I=letterMark = (letterScore/28.0)*marks[k];
  printf("\nYou have score %.2f out of %d in this exercise.",letterMark,marks[k]);
  printf("\nYou have taken %.4f seconds to complete this exercise.",time_taken);
  letterScore=0;
}
else if(exercise[k]=='J')//PRINTING J
    {
    for(int i=0;i<7;i++)
    {
            for(int j=0;j<4;j++)
            {
                if(letterJ[i][j] == 1)
                {
                    printf("*");
                }
                else{
                    printf(" ");
                }

            }
                printf("\n");
    }

        printf("\n\n\tIt's your turn, try it out\n");
startTime=clock();
        for(int i=0;i<7;i++)
        {
            for(int j=0;j<4;j++)
            {
                scanf("%d", &answer[i][j]);	//Accepts input from the pupil

                if(answer[i][j]== letterJ[i][j])
                {
                    letterScore = letterScore + 1;	//letterScore variable is increased by one for each correct point plotted on a letter
                }
            }
TimeJ=clock();
if((((double)(TimeJ-startTime))/CLOCKS_PER_SEC)>50)
{
    printf("Your time has elapsed remember to follow time next time\n");
    break;
}
else
    continue;
        }
endTime=clock();
double time_taken = ((double)(endTime-startTime))/CLOCKS_PER_SEC; // in seconds
tJ=time_taken;
	printf("\n\nThe drawn letter pattern is\n");
for(int i=0;i<7;i++)
{
		for(int j=0;j<4;j++)
		{
			if(answer[i][j] == 1)
			{
				printf("*");
			}
			else{
				printf(" ");
			}

		}
			printf("\n");
}
double timj=50-(((double)(TimeJ-startTime))/CLOCKS_PER_SEC);
if(timj>=1)
    printf("You have finished the exercice %.1f seconds earlier\n",timj);
printf("Correct number of points plotted are %d.",letterScore);
  J=letterMark = (letterScore/28.0)*marks[k];
  printf("\nYou have score %.2f out of %d in this exercise.",letterMark,marks[k]);
  printf("\nYou have taken %.4f seconds to complete this exercise.",time_taken);
  letterScore=0;
}
else if(exercise[k]=='K')//PRINTING K
    {
    for(int i=0;i<7;i++)
    {
            for(int j=0;j<4;j++)
            {
                if(letterK[i][j] == 1)
                {
                    printf("*");
                }
                else{
                    printf(" ");
                }

            }
                printf("\n");
    }

        printf("\n\n\tIt's your turn, try it out\n");
startTime=clock();
        for(int i=0;i<7;i++)
        {
            for(int j=0;j<4;j++)
            {
                scanf("%d", &answer[i][j]);	//Accepts input from the pupil

                if(answer[i][j]== letterK[i][j])
                {
                    letterScore = letterScore + 1;	//letterScore variable is increased by one for each correct point plotted on a letter
                }
            }
TimeK=clock();
if((((double)(TimeK-startTime))/CLOCKS_PER_SEC)>50)
{
    printf("Your time has elapsed remember to follow time next time\n");
    break;
}
else
    continue;
        }
endTime=clock();
double time_taken = ((double)(endTime-startTime))/CLOCKS_PER_SEC; // in seconds
tK=time_taken;
	printf("\n\nThe drawn letter pattern is\n");
for(int i=0;i<7;i++)
{
		for(int j=0;j<4;j++)
		{
			if(answer[i][j] == 1)
			{
				printf("*");
			}
			else{
				printf(" ");
			}

		}
			printf("\n");
}
double timk=50-(((double)(TimeK-startTime))/CLOCKS_PER_SEC);
if(timk>=1)
    printf("You have finished the exercice %.1f seconds earlier\n",timk);
printf("Correct number of points plotted are %d.",letterScore);
  K=letterMark = (letterScore/28.0)*marks[k];
  printf("\nYou have score %.2f out of %d in this exercise.",letterMark,marks[k]);
  printf("\nYou have taken %.4f seconds to complete this exercise.",time_taken);
  letterScore=0;
}
else if(exercise[k]=='L')//PRINTING L
    {
    for(int i=0;i<7;i++)
    {
            for(int j=0;j<4;j++)
            {
                if(letterL[i][j] == 1)
                {
                    printf("*");
                }
                else{
                    printf(" ");
                }

            }
                printf("\n");
    }

        printf("\n\n\tIt's your turn, try it out\n");
startTime=clock();
        for(int i=0;i<7;i++)
        {
            for(int j=0;j<4;j++)
            {
                scanf("%d", &answer[i][j]);	//Accepts input from the pupil

            if(answer[i][j]== letterL[i][j])
                {
                    letterScore = letterScore + 1;	//letterScore variable is increased by one for each correct point plotted on a letter
                }
            }
TimeL=clock();
if((((double)(TimeL-startTime))/CLOCKS_PER_SEC)>50)
{
    printf("Your time has elapsed remember to follow time next time\n");
    break;
}
else
    continue;
        }
endTime=clock();
double time_taken = ((double)(endTime-startTime))/CLOCKS_PER_SEC; // in seconds
tL=time_taken;
	printf("\n\nThe drawn letter pattern is\n");
for(int i=0;i<7;i++)
{
		for(int j=0;j<4;j++)
		{
			if(answer[i][j] == 1)
			{
				printf("*");
			}
			else{
				printf(" ");
			}

		}
			printf("\n");
}
double timl=50-(((double)(TimeL-startTime))/CLOCKS_PER_SEC);
if(timl>=1)
    printf("You have finished the exercice %.1f seconds earlier\n",timl);
printf("Correct number of points plotted are %d.",letterScore);
  L=letterMark = (letterScore/28.0)*marks[k];
  printf("\nYou have score %.2f out of %d in this exercise.",letterMark,marks[k]);
  printf("\nYou have taken %.4f seconds to complete this exercise.",time_taken);
  letterScore=0;
}
else if(exercise[k]=='M')//PRINTING M
    {
    for(int i=0;i<7;i++)
    {
            for(int j=0;j<4;j++)
            {
                if(letterM[i][j] == 1)
                {
                    printf("*");
                }
                else{
                    printf(" ");
                }

            }
                printf("\n");
    }

        printf("\n\n\tIt's your turn, try it out\n");
startTime=clock();
        for(int i=0;i<7;i++)
        {
            for(int j=0;j<4;j++)
            {
                scanf("%d", &answer[i][j]);	//Accepts input from the pupil

            if(answer[i][j]== letterM[i][j])
                {
                    letterScore = letterScore + 1;	//letterScore variable is increased by one for each correct point plotted on a letter
                }
            }
TimeM=clock();
if((((double)(TimeM-startTime))/CLOCKS_PER_SEC)>50)
{
    printf("Your time has elapsed remember to follow time next time\n");
    break;
}
else
    continue;
        }
endTime=clock();
double time_taken = ((double)(endTime-startTime))/CLOCKS_PER_SEC; // in seconds
tM=time_taken;
	printf("\n\nThe drawn letter pattern is\n");
for(int i=0;i<7;i++)
{
		for(int j=0;j<4;j++)
		{
			if(answer[i][j] == 1)
			{
				printf("*");
			}
			else{
				printf(" ");
			}

		}
			printf("\n");
}
double timm=50-(((double)(TimeM-startTime))/CLOCKS_PER_SEC);
if(timm>=1)
    printf("You have finished the exercice %.1f seconds earlier\n",timm);
printf("Correct number of points plotted are %d.",letterScore);
  M=letterMark = (letterScore/28.0)*marks[k];
  printf("\nYou have score %.2f out of %d in this exercise.",letterMark,marks[k]);
  printf("\nYou have taken %.4f seconds to complete this exercise.",time_taken);
  letterScore=0;
}
else if(exercise[k]=='N')//PRINTING N
    {
    for(int i=0;i<7;i++)
    {
            for(int j=0;j<4;j++)
            {
                if(letterN[i][j] == 1)
                {
                    printf("*");
                }
                else{
                    printf(" ");
                }

            }
                printf("\n");
    }

        printf("\n\n\tIt's your turn, try it out\n");
startTime=clock();
        for(int i=0;i<7;i++)
        {
            for(int j=0;j<4;j++)
            {
                scanf("%d", &answer[i][j]);	//Accepts input from the pupil

                if(answer[i][j]== letterN[i][j])
                {
                    letterScore = letterScore + 1;	//letterScore variable is increased by one for each correct point plotted on a letter
                }
            }
TimeN=clock();
if((((double)(TimeN-startTime))/CLOCKS_PER_SEC)>50)
{
    printf("Your time has elapsed remember to follow time next time\n");
    break;
}
else
    continue;
        }
endTime=clock();
double time_taken = ((double)(endTime-startTime))/CLOCKS_PER_SEC; // in seconds
tN=time_taken;
	printf("\n\nThe drawn letter pattern is\n");
for(int i=0;i<7;i++)
{
		for(int j=0;j<4;j++)
		{
			if(answer[i][j] == 1)
			{
				printf("*");
			}
			else{
				printf(" ");
			}

		}
			printf("\n");
}
double timn=50-(((double)(TimeN-startTime))/CLOCKS_PER_SEC);
if(timn>=1)
    printf("You have finished the exercice %.1f seconds earlier\n",timn);
printf("Correct number of points plotted are %d.",letterScore);
  N=letterMark = (letterScore/28.0)*marks[k];
  printf("\nYou have score %.2f out of %d in this exercise.",letterMark,marks[k]);
  printf("\nYou have taken %.4f seconds to complete this exercise.",time_taken);
  letterScore=0;
}
else if(exercise[k]=='O')//PRINTING O
    {
    for(int i=0;i<7;i++)
    {
            for(int j=0;j<4;j++)
            {
                if(letterO[i][j] == 1)
                {
                    printf("*");
                }
                else{
                    printf(" ");
                }

            }
                printf("\n");
    }

        printf("\n\n\tIt's your turn, try it out\n");
startTime=clock();
        for(int i=0;i<7;i++)
        {
            for(int j=0;j<4;j++)
            {
                scanf("%d", &answer[i][j]);	//Accepts input from the pupil

            if(answer[i][j]== letterO[i][j])
                {
                    letterScore = letterScore + 1;	//letterScore variable is increased by one for each correct point plotted on a letter
                }
            }
TimeO=clock();
if((((double)(TimeO-startTime))/CLOCKS_PER_SEC)>50)
{
    printf("Your time has elapsed remember to follow time next time\n");
    break;
}
else
    continue;
        }
endTime=clock();
double time_taken = ((double)(endTime-startTime))/CLOCKS_PER_SEC; // in seconds
tO=time_taken;
	printf("\n\nThe drawn letter pattern is\n");
for(int i=0;i<7;i++)
{
		for(int j=0;j<4;j++)
		{
			if(answer[i][j] == 1)
			{
				printf("*");
			}
			else{
				printf(" ");
			}

		}
			printf("\n");
}
double timo=50-(((double)(TimeO-startTime))/CLOCKS_PER_SEC);
if(timo>=1)
    printf("You have finished the exercice %.1f seconds earlier\n",timo);
printf("Correct number of points plotted are %d.",letterScore);
  O=letterMark = (letterScore/28.0)*marks[k];
  printf("\nYou have score %.2f out of %d in this exercise.",letterMark,marks[k]);
  printf("\nYou have taken %.4f seconds to complete this exercise.",time_taken);
  letterScore=0;
}
else if(exercise[k]=='P')//PRINTING P
    {
    for(int i=0;i<7;i++)
    {
            for(int j=0;j<4;j++)
            {
                if(letterP[i][j] == 1)
                {
                    printf("*");
                }
                else{
                    printf(" ");
                }

            }
                printf("\n");
    }

        printf("\n\n\tIt's your turn, try it out\n");
startTime=clock();
        for(int i=0;i<7;i++)
        {
            for(int j=0;j<4;j++)
            {
                scanf("%d", &answer[i][j]);	//Accepts input from the pupil

               if(answer[i][j]== letterP[i][j])
                {
                    letterScore = letterScore + 1;	//letterScore variable is increased by one for each correct point plotted on a letter
                }
            }
TimeP=clock();
if((((double)(TimeP-startTime))/CLOCKS_PER_SEC)>50)
{
    printf("Your time has elapsed remember to follow time next time\n");
    break;
}
else
    continue;
        }
endTime=clock();
double time_taken = ((double)(endTime-startTime))/CLOCKS_PER_SEC; // in seconds
tP=time_taken;
	printf("\n\nThe drawn letter pattern is\n");
for(int i=0;i<7;i++)
{
		for(int j=0;j<4;j++)
		{
			if(answer[i][j] == 1)
			{
				printf("*");
			}
			else{
				printf(" ");
			}

		}
			printf("\n");
}
double timp=50-(((double)(TimeP-startTime))/CLOCKS_PER_SEC);
if(timp>=1)
    printf("You have finished the exercice %.1f seconds earlier\n",timp);
printf("Correct number of points plotted are %d.",letterScore);
  P=letterMark = (letterScore/28.0)*marks[k];
  printf("\nYou have score %.2f out of %d in this exercise.",letterMark,marks[k]);
  printf("\nYou have taken %.4f seconds to complete this exercise.",time_taken);
  letterScore=0;
}
else if(exercise[k]=='Q')//PRINTING Q
    {
    for(int i=0;i<7;i++)
    {
            for(int j=0;j<4;j++)
            {
                if(letterQ[i][j] == 1)
                {
                    printf("*");
                }
                else{
                    printf(" ");
                }

            }
                printf("\n");
    }

        printf("\n\n\tIt's your turn, try it out\n");
startTime=clock();
        for(int i=0;i<7;i++)
        {
            for(int j=0;j<4;j++)
            {
                scanf("%d", &answer[i][j]);	//Accepts input from the pupil

               if(answer[i][j]== letterQ[i][j])
                {
                    letterScore = letterScore + 1;	//letterScore variable is increased by one for each correct point plotted on a letter
                }
            }
TimeQ=clock();
if((((double)(TimeQ-startTime))/CLOCKS_PER_SEC)>50)
{
    printf("Your time has elapsed remember to follow time next time\n");
    break;
}
else
    continue;
        }
endTime=clock();
double time_taken = ((double)(endTime-startTime))/CLOCKS_PER_SEC; // in seconds
tQ=time_taken;
	printf("\n\nThe drawn letter pattern is\n");
for(int i=0;i<7;i++)
{
		for(int j=0;j<4;j++)
		{
			if(answer[i][j] == 1)
			{
				printf("*");
			}
			else{
				printf(" ");
			}

		}
			printf("\n");
}
double timq=50-(((double)(TimeQ-startTime))/CLOCKS_PER_SEC);
if(timq>=1)
    printf("You have finished the exercice %.1f seconds earlier\n",timq);
printf("Correct number of points plotted are %d.",letterScore);
  Q=letterMark = (letterScore/28.0)*marks[k];
  printf("\nYou have score %.2f out of %d in this exercise.",letterMark,marks[k]);
  printf("\nYou have taken %.4f seconds to complete this exercise.",time_taken);
  letterScore=0;
}
else if(exercise[k]=='R')//PRINTING R
    {
    for(int i=0;i<7;i++)
    {
            for(int j=0;j<4;j++)
            {
                if(letterR[i][j] == 1)
                {
                    printf("*");
                }
                else{
                    printf(" ");
                }

            }
                printf("\n");
    }

        printf("\n\n\tIt's your turn, try it out\n");
startTime=clock();
        for(int i=0;i<7;i++)
        {
            for(int j=0;j<4;j++)
            {
                scanf("%d", &answer[i][j]);	//Accepts input from the pupil

               if(answer[i][j]== letterR[i][j])
                {
                    letterScore = letterScore + 1;	//letterScore variable is increased by one for each correct point plotted on a letter
                }
            }
TimeR=clock();
if((((double)(TimeR-startTime))/CLOCKS_PER_SEC)>50)
{
    printf("Your time has elapsed remember to follow time next time\n");
    break;
}
else
    continue;
        }
endTime=clock();
double time_taken = ((double)(endTime-startTime))/CLOCKS_PER_SEC; // in seconds
tR=time_taken;
	printf("\n\nThe drawn letter pattern is\n");
for(int i=0;i<7;i++)
{
		for(int j=0;j<4;j++)
		{
			if(answer[i][j] == 1)
			{
				printf("*");
			}
			else{
				printf(" ");
			}

		}
			printf("\n");
}
double timr=50-(((double)(TimeR-startTime))/CLOCKS_PER_SEC);
if(timr>=1)
    printf("You have finished the exercice %.1f seconds earlier\n",timr);
printf("Correct number of points plotted are %d.",letterScore);
  R=letterMark = (letterScore/28.0)*marks[k];
  printf("\nYou have score %.2f out of %d in this exercise.",letterMark,marks[k]);
  printf("\nYou have taken %.4f seconds to complete this exercise.",time_taken);
  letterScore=0;
}
else if(exercise[k]=='S')//PRINTING S
    {
    for(int i=0;i<7;i++)
    {
            for(int j=0;j<4;j++)
            {
                if(letterS[i][j] == 1)
                {
                    printf("*");
                }
                else{
                    printf(" ");
                }

            }
                printf("\n");
    }

        printf("\n\n\tIt's your turn, try it out\n");
startTime=clock();
        for(int i=0;i<7;i++)
        {
            for(int j=0;j<4;j++)
            {
                scanf("%d", &answer[i][j]);	//Accepts input from the pupil

            if(answer[i][j]== letterS[i][j])
                {
                    letterScore = letterScore + 1;	//letterScore variable is increased by one for each correct point plotted on a letter
                }
            }
TimeS=clock();
if((((double)(TimeS-startTime))/CLOCKS_PER_SEC)>50)
{
    printf("Your time has elapsed remember to follow time next time\n");
    break;
}
else
    continue;
        }
endTime=clock();
double time_taken = ((double)(endTime-startTime))/CLOCKS_PER_SEC; // in seconds
tS=time_taken;
	printf("\n\nThe drawn letter pattern is\n");
for(int i=0;i<7;i++)
{
		for(int j=0;j<4;j++)
		{
			if(answer[i][j] == 1)
			{
				printf("*");
			}
			else{
				printf(" ");
			}

		}
			printf("\n");
}
double tims=50-(((double)(TimeS-startTime))/CLOCKS_PER_SEC);
if(tims>=1)
    printf("You have finished the exercice %.1f seconds earlier\n",tims);
printf("Correct number of points plotted are %d.",letterScore);
  S=letterMark = (letterScore/28.0)*marks[k];
  printf("\nYou have score %.2f out of %d in this exercise.",letterMark,marks[k]);
  printf("\nYou have taken %.4f seconds to complete this exercise.",time_taken);
  letterScore=0;
}
else if(exercise[k]=='T')//PRINTING T
    {
    for(int i=0;i<7;i++)
    {
            for(int j=0;j<4;j++)
            {
                if(letterT[i][j] == 1)
                {
                    printf("*");
                }
                else{
                    printf(" ");
                }

            }
                printf("\n");
    }

        printf("\n\n\tIt's your turn, try it out\n");
startTime=clock();
        for(int i=0;i<7;i++)
        {
            for(int j=0;j<4;j++)
            {
                scanf("%d", &answer[i][j]);	//Accepts input from the pupil

               if(answer[i][j]== letterT[i][j])
                {
                    letterScore = letterScore + 1;	//letterScore variable is increased by one for each correct point plotted on a letter
                }
            }
TimeT=clock();
if((((double)(TimeT-startTime))/CLOCKS_PER_SEC)>50)
{
    printf("Your time has elapsed remember to follow time next time\n");
    break;
}
else
    continue;
        }
endTime=clock();
double time_taken = ((double)(endTime-startTime))/CLOCKS_PER_SEC; // in seconds
tT=time_taken;
	printf("\n\nThe drawn letter pattern is\n");
for(int i=0;i<7;i++)
{
		for(int j=0;j<4;j++)
		{
			if(answer[i][j] == 1)
			{
				printf("*");
			}
			else{
				printf(" ");
			}

		}
			printf("\n");
}
double timt=50-(((double)(TimeT-startTime))/CLOCKS_PER_SEC);
if(timt>=1)
    printf("You have finished the exercice %.1f seconds earlier\n",timt);
printf("Correct number of points plotted are %d.",letterScore);
  T=letterMark = (letterScore/28.0)*marks[k];
  printf("\nYou have score %.2f out of %d in this exercise.",letterMark,marks[k]);
  printf("\nYou have taken %.4f seconds to complete this exercise.",time_taken);
  letterScore=0;
}
else if(exercise[k]=='U')//PRINTING U
    {
    for(int i=0;i<7;i++)
    {
            for(int j=0;j<4;j++)
            {
                if(letterU[i][j] == 1)
                {
                    printf("*");
                }
                else{
                    printf(" ");
                }

            }
                printf("\n");
    }

        printf("\n\n\tIt's your turn, try it out\n");
startTime=clock();
        for(int i=0;i<7;i++)
        {
            for(int j=0;j<4;j++)
            {
                scanf("%d", &answer[i][j]);	//Accepts input from the pupil

               if(answer[i][j]== letterU[i][j])
                {
                    letterScore = letterScore + 1;	//letterScore variable is increased by one for each correct point plotted on a letter
                }
            }
TimeU=clock();
if((((double)(TimeU-startTime))/CLOCKS_PER_SEC)>50)
{
    printf("Your time has elapsed remember to follow time next time\n");
    break;
}
else
    continue;
        }
endTime=clock();
double time_taken = ((double)(endTime-startTime))/CLOCKS_PER_SEC; // in seconds
tU=time_taken;
	printf("\n\nThe drawn letter pattern is\n");
for(int i=0;i<7;i++)
{
		for(int j=0;j<4;j++)
		{
			if(answer[i][j] == 1)
			{
				printf("*");
			}
			else{
				printf(" ");
			}

		}
			printf("\n");
}
double timu=50-(((double)(TimeU-startTime))/CLOCKS_PER_SEC);
if(timu>=1)
    printf("You have finished the exercice %.1f seconds earlier\n",timu);
printf("Correct number of points plotted are %d.",letterScore);
  U=letterMark = (letterScore/28.0)*marks[k];
  printf("\nYou have score %.2f out of %d in this exercise.",letterMark,marks[k]);
  printf("\nYou have taken %.4f seconds to complete this exercise.",time_taken);
  letterScore=0;
}
else if(exercise[k]=='V')//PRINTING V
    {
    for(int i=0;i<7;i++)
    {
            for(int j=0;j<4;j++)
            {
                if(letterV[i][j] == 1)
                {
                    printf("*");
                }
                else{
                    printf(" ");
                }

            }
                printf("\n");
    }

        printf("\n\n\tIt's your turn, try it out\n");
startTime=clock();
        for(int i=0;i<7;i++)
        {
            for(int j=0;j<4;j++)
            {
                scanf("%d", &answer[i][j]);	//Accepts input from the pupil

            if(answer[i][j]== letterV[i][j])
                {
                    letterScore = letterScore + 1;	//letterScore variable is increased by one for each correct point plotted on a letter
                }
            }
TimeV=clock();
if((((double)(TimeV-startTime))/CLOCKS_PER_SEC)>50)
{
    printf("Your time has elapsed remember to follow time next time\n");
    break;
}
else
    continue;
        }
endTime=clock();
double time_taken = ((double)(endTime-startTime))/CLOCKS_PER_SEC; // in seconds
tV=time_taken;
	printf("\n\nThe drawn letter pattern is\n");
for(int i=0;i<7;i++)
{
		for(int j=0;j<4;j++)
		{
			if(answer[i][j] == 1)
			{
				printf("*");
			}
			else{
				printf(" ");
			}

		}
			printf("\n");
}
double timv=50-(((double)(TimeV-startTime))/CLOCKS_PER_SEC);
if(timv>=1)
    printf("You have finished the exercice %.1f seconds earlier\n",timv);
printf("Correct number of points plotted are %d.",letterScore);
  V=letterMark = (letterScore/28.0)*marks[k];
  printf("\nYou have score %.2f out of %d in this exercise.",letterMark,marks[k]);
  printf("\nYou have taken %.4f seconds to complete this exercise.",time_taken);
  letterScore=0;
}
else if(exercise[k]=='W')//PRINTING W
    {
    for(int i=0;i<7;i++)
    {
            for(int j=0;j<4;j++)
            {
                if(letterW[i][j] == 1)
                {
                    printf("*");
                }
                else{
                    printf(" ");
                }

            }
                printf("\n");
    }

        printf("\n\n\tIt's your turn, try it out\n");
startTime=clock();
        for(int i=0;i<7;i++)
        {
            for(int j=0;j<4;j++)
            {
                scanf("%d", &answer[i][j]);	//Accepts input from the pupil

               if(answer[i][j]== letterW[i][j])
                {
                    letterScore = letterScore + 1;	//letterScore variable is increased by one for each correct point plotted on a letter
                }
            }
TimeW=clock();
if((((double)(TimeW-startTime))/CLOCKS_PER_SEC)>50)
{
    printf("Your time has elapsed remember to follow time next time\n");
    break;
}
else
    continue;
        }
endTime=clock();
double time_taken = ((double)(endTime-startTime))/CLOCKS_PER_SEC; // in seconds
tW=time_taken;
	printf("\n\nThe drawn letter pattern is\n");
for(int i=0;i<7;i++)
{
		for(int j=0;j<4;j++)
		{
			if(answer[i][j] == 1)
			{
				printf("*");
			}
			else{
				printf(" ");
			}

		}
			printf("\n");
}
double timw=50-(((double)(TimeW-startTime))/CLOCKS_PER_SEC);
if(timw>=1)
    printf("You have finished the exercice %.1f seconds earlier\n",timw);
printf("Correct number of points plotted are %d.",letterScore);
  W=letterMark = (letterScore/28.0)*marks[k];
  printf("\nYou have score %.2f out of %d in this exercise.",letterMark,marks[k]);
  printf("\nYou have taken %.4f seconds to complete this exercise.",time_taken);
  letterScore=0;
}
else if(exercise[k]=='X')//PRINTING X
    {
    for(int i=0;i<7;i++)
    {
            for(int j=0;j<4;j++)
            {
                if(letterX[i][j] == 1)
                {
                    printf("*");
                }
                else{
                    printf(" ");
                }

            }
                printf("\n");
    }

        printf("\n\n\tIt's your turn, try it out\n");
startTime=clock();
        for(int i=0;i<7;i++)
        {
            for(int j=0;j<4;j++)
            {
                scanf("%d", &answer[i][j]);	//Accepts input from the pupil

            if(answer[i][j]== letterX[i][j])
                {
                    letterScore = letterScore + 1;	//letterScore variable is increased by one for each correct point plotted on a letter
                }
            }
TimeX=clock();
if((((double)(TimeX-startTime))/CLOCKS_PER_SEC)>50)
{
    printf("Your time has elapsed remember to follow time next time\n");
    break;
}
else
    continue;
        }
endTime=clock();
double time_taken = ((double)(endTime-startTime))/CLOCKS_PER_SEC; // in seconds
tX=time_taken;
	printf("\n\nThe drawn letter pattern is\n");
for(int i=0;i<7;i++)
{
		for(int j=0;j<4;j++)
		{
			if(answer[i][j] == 1)
			{
				printf("*");
			}
			else{
				printf(" ");
			}

		}
			printf("\n");
}
double timx=50-(((double)(TimeX-startTime))/CLOCKS_PER_SEC);
if(timx>=1)
    printf("You have finished the exercice %.1f seconds earlier\n",timx);
printf("Correct number of points plotted are %d.",letterScore);
  X=letterMark = (letterScore/28.0)*marks[k];
  printf("\nYou have score %.2f out of %d in this exercise.",letterMark,marks[k]);
  printf("\nYou have taken %.4f seconds to complete this exercise.",time_taken);
  letterScore=0;
}
else if(exercise[k]=='Y')//PRINTING Y
    {
    for(int i=0;i<7;i++)
    {
            for(int j=0;j<4;j++)
            {
                if(letterY[i][j] == 1)
                {
                    printf("*");
                }
                else{
                    printf(" ");
                }

            }
                printf("\n");
    }

        printf("\n\n\tIt's your turn, try it out\n");
startTime=clock();
        for(int i=0;i<7;i++)
        {
            for(int j=0;j<4;j++)
            {
                scanf("%d", &answer[i][j]);	//Accepts input from the pupil

            if(answer[i][j]== letterY[i][j])
                {
                    letterScore = letterScore + 1;	//letterScore variable is increased by one for each correct point plotted on a letter
                }
            }
TimeY=clock();
if((((double)(TimeY-startTime))/CLOCKS_PER_SEC)>50)
{
    printf("Your time has elapsed remember to follow time next time\n");
    break;
}
else
    continue;
        }
endTime=clock();
double time_taken = ((double)(endTime-startTime))/CLOCKS_PER_SEC; // in seconds
tY=time_taken;
	printf("\n\nThe drawn letter pattern is\n");
for(int i=0;i<7;i++)
{
		for(int j=0;j<4;j++)
		{
			if(answer[i][j] == 1)
			{
				printf("*");
			}
			else{
				printf(" ");
			}

		}
			printf("\n");
}
double timy=50-(((double)(TimeY-startTime))/CLOCKS_PER_SEC);
if(timy>=1)
    printf("You have finished the exercice %.1f seconds earlier\n",timy);
printf("Correct number of points plotted are %d.",letterScore);
  Y=letterMark = (letterScore/28.0)*marks[k];
  printf("\nYou have score %.2f out of %d in this exercise.",letterMark,marks[k]);
  printf("\nYou have taken %.4f seconds to complete this exercise.",time_taken);
  letterScore=0;
}
else if(exercise[k]=='Z')//PRINTING Z
    {
    for(int i=0;i<7;i++)
    {
            for(int j=0;j<4;j++)
            {
                if(letterZ[i][j] == 1)
                {
                    printf("*");
                }
                else{
                    printf(" ");
                }

            }
                printf("\n");
    }

        printf("\n\n\tIt's your turn, try it out\n");
startTime=clock();
        for(int i=0;i<7;i++)
        {
            for(int j=0;j<4;j++)
            {
                scanf("%d", &answer[i][j]);	//Accepts input from the pupil

            if(answer[i][j]== letterZ[i][j])
                {
                    letterScore = letterScore + 1;	//letterScore variable is increased by one for each correct point plotted on a letter
                }
            }
TimeZ=clock();
if((((double)(TimeZ-startTime))/CLOCKS_PER_SEC)>50)
{
    printf("Your time has elapsed remember to follow time next time\n");
    break;
}
else
    continue;
        }
endTime=clock();
double time_taken = ((double)(endTime-startTime))/CLOCKS_PER_SEC; // in seconds
tZ=time_taken;
	printf("\n\nThe drawn letter pattern is\n");
for(int i=0;i<7;i++)
{
		for(int j=0;j<4;j++)
		{
			if(answer[i][j] == 1)
			{
				printf("*");
			}
			else{
				printf(" ");
			}

		}
			printf("\n");
}
double timz=50-(((double)(TimeZ-startTime))/CLOCKS_PER_SEC);
if(timz>=1)
    printf("You have finished the exercice %.1f seconds earlier\n",timz);
printf("Correct number of points plotted are %d.",letterScore);
  Z=letterMark = (letterScore/28.0)*marks[k];
  printf("\nYou have score %.2f out of %d in this exercise.",letterMark,marks[k]);
  printf("\nYou have taken %.4f seconds to complete this exercise.",time_taken);
  letterScore=0;
}
    }
double TotalTimeTaken=tA+tB+tC+tD+tE+tF+tG+tH+tI+tJ+tK+tL+tM+tN+tO+tP+tQ+tR+tS+tT+tU+tV+tW+tX+tY+tZ;
float Totalmarks=A+B+C+D+E+F+G+H+I+J+K+L+M+N+O+P+Q+R+S+T+U+V+W+X+Y+Z;
    int sum=0;
    for(int d=0;d<m;d++)
    {
        sum=sum + marks[d];
    }
    float finalmarks=(Totalmarks/sum)*100;
    printf("\nYour final mark is %.1f%%.",finalmarks);
    float PercentageAttempted=finalmarks;
    float PercentageMissed=(100-PercentageAttempted);
  printf("\nYou have taken total time of %.1f seconds to complete the assignment.\n\n",TotalTimeTaken);
  //printf("\nPercentage attempted is %.1f%%.",PercentageAttempted);
  //printf("\nPercentage missed is %.1f%%.",PercentageMissed);
  float AverageScore=sum/m;
  printf("\nYour average score is %.1f\n",AverageScore);


    sprintf(sqlquery,"INSERT INTO pScores (assign_id,pcode,score) VALUES ('%s','%s','%f')",assignment_id,p_code,finalmarks);
                 if (mysql_query(conn, sqlquery) != 0)
                 {
                 fprintf(stderr, "OOOps!! Your request was unable to process. %s\n",mysql_error(conn));
                 goto label;
                 }
                 printf("Great!! Your assignment  was submitted successfully.\n\n");
                // mysql_close(conn);
                goto label;


    }




            }







            return 0;
         }
