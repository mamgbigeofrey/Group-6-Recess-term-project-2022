
<?php

$server='localhost';
$username='root';
$password='';
$dbname='kcaa';
$table='teacherAccount';

if(isset($_POST['createAccount'])){
    
    $FIRSTNAME= $_POST['tfname'];
    $LASTNAME= $_POST['tlname'];
    $EMAIL= $_POST['temail'];
    $PHONE= $_POST['tphone'];
    $USERNAME= $_POST['tusername'];
    $CODE= $_POST['tcode'];
    
}
$dbconnect=mysqli_connect($server,$username,$password,$dbname);
if(mysqli_connect_errno()){
    echo "Failed to connect to database";
}
else
{
    echo "Database connection successiful";
}

$sql="insert into  $table (FIRSTNAME,LASTNAME,EMAIL,PHONE,USERNAME,CODE) values ('$FIRSTNAME','$LASTNAME','$EMAIL','$PHONE',' $USERNAME','$CODE') ";

$run=mysqli_query($dbconnect,$sql);
if($run =FALSE){
    echo "ERROR";
}
else{
    echo "Data inserted into table";
}

header("Location: ../index.php?New account created succesifully=SUCCESS");



?>

