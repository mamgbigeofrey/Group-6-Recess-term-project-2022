<!doctype html>
	<!DOCTYPE html>
	<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>KinderCare Academic Application </title>
		<link rel="stylesheet" type="text/css" href="style.css">
	</head>
	<body>
		<nav>
			<p>KINDERCARE ACADEMIC APPLICATION<p>
		</nav>
		<div class="create-container">
		
			<form method="POST" action="PHP/newAccount.php" class="createform">
				<label for="tfname">Teacher first name</label>
				<input type="text" name="tfname" id="tfname" placeholder="Enter your first name e.g RICHARD" required>
				<label for="tlname">Teacher Last Name</label>
				<input type="text" name="tlname" id="tlname" placeholder="Enter your last name e.g BIRUNJI" required>
				<label for="temail">Teacher email</label>
				<input type="text" name="temail" id="temail" placeholder="e.g someone@gmail.com" required>
				<label for="tphone">Teacher Phone number</label>
				<input type="text" name="tphone" id="tphone" placeholder="e.g 0770600452" required>
				<label for="tusername">Teacher username</label>
				<input type="text" name="tusername" id="tusername" placeholder="Enter your username" required>
				<label for="tcode">Teacher Code</label>
				<input type="password" name="tcode" id="tcode" placeholder="Enter your usercode" required>
				<button name="createAccount" type="submit">CREATE ACCOUNT</button>
			</form>
		</div>
	
	</body>
	</html>