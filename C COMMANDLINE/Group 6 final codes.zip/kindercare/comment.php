<html>
    <head>
        <title>Kindercare Academic Application</title>
        <style>
            form{
                width: 40%;
                margin: auto;
                margin-top: 20%;
                background-color: ghostwhite;
                text-align: center;
                
            }
            input{
                width: 98%;
                
            }
            button{
                width: 40%;
                margin: auto;
                margin-top: 40px;
            }
        </style>
    </head>
    <?php
    $dbconnect=mysqli_connect("localhost","root","","kcaa");

    if(isset($_POST['btn'])){
        $sql="SELECT * FROM pScores;";
        $result=mysqli_query($dbconnect,$sql);
        
            $row=mysqli_fetch_assoc($result);
        $assignment=$row['assign_id'];
        $ids=$row['id'];
        //foreach($row as $ids){
            
            $content=$_POST['commen'];
        $sqlquery=mysqli_query($dbconnect,"UPDATE pScores SET comment='$content' where id='$ids'AND assign_id='$assignment'");
        if($sqlquery==TRUE){
            header("Location: ../pupilRecord.php");
            
        }
        else
        {
            echo "Comment not sent";
        }
        //}
    
        
    }
    ?>
    <body>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>">
            <input type="text" name="commen">
            <button type="submit" name="btn">Add</button>
        </form>
    </body>
</html>