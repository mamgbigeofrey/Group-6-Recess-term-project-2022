
<?php

$server='localhost';
$username='root';
$password='';
$dbname='kcaa';
$table='login';

if(isset($_POST['loginSubmit'])){
    
    $USERNAME= $_POST['username'];
    $CODE= $_POST['usercode'];
    $dbconnect=mysqli_connect($server,$username,$password,$dbname);
if(mysqli_connect_errno()){
    echo "Failed to connect to database";
}
else
{
    echo "Database connection successiful";
}

$sql="SELECT * FROM teacherAccount where CODE===$CODE LIMIT 1 ";
$authenticate=mysqli_query($dbconnect,$sql);
if($authenticate){
    if (mysqli_num_row($authenticate)==1) {
        $output=mysqli_fetch_assoc($authenticate);
        $_SESSION['username']==$_USERNAME;
        $_SESSION['usercode']==$_CODE;
    header("Location: ../mainpage.php?Login processed succesifully=SUCCESS");
}
else {
    echo "password or username is incorrect";
    header("Location: ../index.php? Please log in again");
}

}
}

?>

