<!DOCTYPE html>
<?php
$server='localhost';
$username='root';
$password='';
$dbname='kcaa';
$table='assignment';

$dbconnect=mysqli_connect($server,$username,$password,$dbname);
?>
	<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>KinderCare Academic Application</title>
		<link rel="stylesheet" type="text/css" href="style.css ">
        <style>
            table{width: 80%; margin: auto;}
            td{width: 15%; background-color: aliceblue; margin-top:10px;}
            thead{color: red; text-transform: uppercase; font-size: 24px;}
            p{font-size: ;font-weight: bold; text-align: center; margin-top: 5px; margin-bottom: 5px;}
            tr{transition: 1s;}
            tr:hover{cursor: pointer;color:blue;}
            .activate{background-color: green; width: 80%; border-radius: 5px;}
            .deactivate{background-color: red; width: 80%; border-radius: 5px;}
        </style>
	</head>
	<body>

		<?php
		session_start();
		if(!isset($_SESSION['loggedin'])){
			header('Location: index.php');
			exit;
		}

		 ?>
       
        
        <?php 
        if(isset($_POST['upload'])){
            $Note=$_POST['more-details'];
            $StartTime=$_POST['starttime'];
            $EndTime=$_POST['endtime'];
            $Marks=$_POST['marks'];
            $Char=$_POST['char'];
            if(!empty($_POST['char'])){
            $char=implode(" ",$_POST['char']);
             $query=   mysqli_query($dbconnect,"INSERT INTO $table (note,starttime,endtime,characters,assigned_marks) VALUES('$Note','$StartTime','$EndTime','$char','$Marks')");
                if($query==true){
                    header("Location: ../assignment.php"); 
                }
                else {
                    echo mysqli_error($dbconnect);
                }
            }   
        }
            
         ?>
		<nav class="index_nav">
            <img src="images/kindercare-logo.png">
            <h1>KinderCare Academic Application</h1>
            <ul>
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="#assign_record">View assignments</a></li>
                <form action="PHP/logout.php" method="POST">
            		<li><button type="submit">Log Out</button></li>
            	</form>
            </ul>
        </nav>
		<div class="assignment_overlayer">
			<div class="add-characters" style="color: white;">
				<p>You can only add a minimum of 1 and a maximum of 8 characters to the assignment list</p>
				
				<h6 style="background:seagreen; width:80%;margin:auto; padding-top:30px; padding-bottom:20px;">POST AN ASSIGNMENT</h6>
			</div>

			<form  name="assign_form" method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" class="assignment-upload">
				<textarea name="more-details" placeholder="Any details acompanying the assignment? Please type it here!" rows="5"></textarea>
                <p>Please select the characters to add to the assignment list</p>
				<div class="character-checkbox" id="character_check">
					<fieldset>
                        <input  type="checkbox" name="char[]" id="A" value="A">A<br>
                    </fieldset>
					<fieldset>
                        <input  type="checkbox" name="char[]" id="B" value="B">B<br>
                    </fieldset>
					<fieldset>
                        <input  type="checkbox" name="char[]" id="C" value="C">C<br>
                    </fieldset>
					<fieldset>
                        <input  type="checkbox" name="char[]" id="D" value="D">D<br>       
                    </fieldset>
					<fieldset>
                        <input  type="checkbox" name="char[]" id="E" value="E" >E<br>               
                    </fieldset>
					<fieldset>
                        <input  type="checkbox" name="char[]" id="F" value="F" >F<br>
                    </fieldset>
					<fieldset>
                        <input  type="checkbox" name="char[]" id="G" value="G" >G<br>
                    </fieldset>
					<fieldset>
                        <input  type="checkbox" name="char[]" id="H" value="H">H<br>
                    </fieldset>
					<fieldset>
                        <input type="checkbox" name="char[]" id="I" value="I">I<br>
                    </fieldset>
					<fieldset>
                        <input  type="checkbox" name="char[]" id="J" value="J">J<br>
                    </fieldset>
					<fieldset>
                        <input  type="checkbox" name="char[]" id="K" value="K">K<br>
                    </fieldset>
					<fieldset>
                        <input  type="checkbox" name="char[]" id="L" value="L">L<br>
                    </fieldset>
					<fieldset>
                        <input  type="checkbox" name="char[]" id="M" value="M">M<br>
                    </fieldset>
					<fieldset>
                        <input type="checkbox" name="char[]" id="N" value="N">N<br>
                    </fieldset>
					<fieldset>
                        <input type="checkbox" name="char[]" id="O" value="O">O<br>
                    </fieldset>
					<fieldset>
                        <input type="checkbox" name="char[]" id="P" value="P" >P<br>
                    </fieldset>
					<fieldset>
                        <input  type="checkbox" name="char[]" id="Q" value="Q">Q<br>
                    </fieldset>
					<fieldset>
                        <input  type="checkbox" name="char[]" id="R" value="R">R<br>
                    </fieldset>
					<fieldset>
                        <input  type="checkbox" name="char[]" id="S" value="S" >S<br>
                    </fieldset>
					<fieldset>
                        <input type="checkbox" name="char[]" id="T" value="T" >T<br>
                    </fieldset>
					<fieldset>
                        <input type="checkbox" name="char[]" id="U" value="U">U<br>
                    </fieldset>
					<fieldset>
                        <input  type="checkbox" name="char[]" id="V" value="V">V<br>
                    </fieldset>
					<fieldset>
                        <input type="checkbox" name="char[]" id="W" value="W">W<br>
                    </fieldset>
					<fieldset>
                        <input type="checkbox" name="char[]" id="X" value="X">X<br>
                    </fieldset>
					<fieldset>
                        <input type="checkbox" name="char[]" id="Y" value="Y" >Y<br>
                    </fieldset>
					<fieldset>
                        <input type="checkbox" name="char[]" id="Z" value="Z">Z<br>
                    </fieldset>
				</div>
                <p style="margin-top:15px;">Please allocate the marks for each of the characters selected above in the order of their selection separated by a comma.</p>
                <div class="marks-allocation">
                    <input type="text" placeholder="Enter marks for the characters eg 5,7,12,34,etc" name="marks">
                </div>
					<label for="starttime">Start Time</label>
					<input type="datetime-local" name="starttime" id="starttime" required>
					<label for="endtime">End Time</label>
					<input type="datetime-local" name="endtime" id="endtime" required>
					<button name="upload" type="submit" id="upload">Upload assignment</button>
			</form>
		
		</div>
        <div class="assign_record" id="assign_record">
            <p>Below is the list of all the assignments so far uploaded.</p>
             <table>
                <thead>
                <td>ASSIGNMENT ID</td>
                <td>GIVEN ON</td>
                <td>CHARACTERS</td>
                <td>START TIME</td>
                <td>END TIME</td>
                </thead>
            </table>
            
	
<?php
require('PHP/connection.php');
$sql="SELECT * FROM assignment;";
$result=mysqli_query($dbconnect,$sql);
while ($row=mysqli_fetch_array($result)) {
	?>
	<table>
        
		<tr>
            <td><?php echo $row['id'];?></td>
            <td><?php echo $row['uploaded_on'];?></td>
            <td><?php echo $row['characters'];?></td>
            <td><?php echo $row['starttime'];?></td>
            <td><?php echo $row['endtime'];?></td>
            
        </tr>
	<?php
	
}
?>
	</table>
        </div>
        
        <footer class="footer_section">
                <h3>Kindercare academic application system development by recess group G-6</h3>
        <h5>Below are our team of developers</h5>
                <div class="footer_container">
                    <div class="item_cont">
                        <img src="images/team/geof.jpg">
                        <h4>Mamgbi Geofrey</h4>
                        <p>RegNo: 20/U/22748</p>
                    </div>
                    <div class="item_cont">
                        <img src="images/team/phionah.jpg" style="width:45%;">
                        <h4>Mumararungu Phionah</h4>
                        <p>RegNo: 20/U/7749/PS</p>
                    </div>
                    <div class="item_cont">
                        <img src="images/team/mary.jpg">
                        <h4>Nakinoneka Mary Margret</h4>
                        <p>RegNo: 20/U/22748</p>
                    </div>
                    <div class="item_cont">
                        <img src="images/team/emman.jpg" >
                        <h4>Emmanuel Abdallah Odori</h4>
                        <p>RegNo: 20/U/7771/PS</p>
                    </div>
                    
                </div>
                <p>For more information/queries, you can reach us via the contacts below</p>
                    <p>Email us on:<a href="mailto:gmamgbi1999@gmail.com" style="color:blue;">gmamgbi1999@gmail.com</a><br>Or call us on:<a href="tel:+256770600452" style="color:blue;">0770600452</a></p>
                    <div class="copyright">&copy; Copyright <strong><span>Recess term Group-6 		@2022</span></strong>. All Rights Reserved
                    </div>
      <div class="credits">
        Designed with <img src="images/team/heart%20logO.png" style="width:2%; border-radius: 50%; margin-top: 10px;"> by <a href="http//www.Sensycodez.000webhostapp.com">G-6</a>
        </div>
        </footer>

		<script src="JavaScript/assignment.js"></script>
	</body>

	
	</html>