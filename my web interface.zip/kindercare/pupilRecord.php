<!doctype html>
	<!DOCTYPE html>
	<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>KinderCare Academic Application</title>
		<link rel="stylesheet" type="text/css" href="style.css">
	</head>
	<body>
		<form method="POST" action="PHP/pRECORD.php">
			<button id="pupil_record" name="pupil_record">View pupil record</button>
		</form>
	
	</body>
	</html>