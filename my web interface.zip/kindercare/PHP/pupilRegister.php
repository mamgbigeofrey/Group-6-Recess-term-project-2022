
<?php

$server='localhost';
$username='root';
$password='';
$dbname='kcaa';
$table='pupilRegister';

if(isset($_POST['pregbtn'])){
    
    $FIRSTNAME= $_POST['pfname'];
    $LASTNAME= $_POST['plname'];
    $PHONE= $_POST['ptel'];
    $CODE= $_POST['pcode'];
    
}
$dbconnect=mysqli_connect($server,$username,$password,$dbname);
if(mysqli_connect_errno()){
    echo "Failed to connect to database";
}
else
{
    echo "Database connection successiful";
}

$sql="insert into  $table (FIRSTNAME,LASTNAME,PHONE,CODE) values ('$FIRSTNAME','$LASTNAME','$PHONE','$CODE') ";

$run=mysqli_query($dbconnect,$sql);
if($run =FALSE){
    echo "ERROR";
}
else{
    echo "Data inserted into table";
}

header("Location: ../pupilRegister.php?New account created succesifully=SUCCESS");



?>

