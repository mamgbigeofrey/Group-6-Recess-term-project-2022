
var form= getElementsByName('more-details') ;

var checkBoxes = form.querySelectorAll('input[type="checkbox"]'); // get all the check box
        document.getElementById('upload').addEventListener('click', getData); //add a click event to the save button
 
 
  
  let Error = true;
 //getting data from checkBoxes
      
   function selectcharacter() { // this function will get called when the save button is clicked

            checkBoxes.forEach(char[]=> { // loop all the checkbox item
                if (char[].checked) {  //if the check box is checked
                    error = false;
                }
            });
            if (checkBoxes.getAll("char[]")<8) {
                alert("Allowed to add a minimum  of eight characters...");
            }
         
          else if (checkBoxes.getAll("char[]")>8) {
                alert("Allowed to pick only   eight characters...");
            }
            else  if (checkBoxes.getAll("char[]")==8){
                alert("Upload assignment..");
            }
        }
       
    
    
  