const fname= document.getElementById('pfname');
const lname= document.getElementById('plname');
const email= document.getElementById('ptel');

const pswd= document.getElementById('tcode');
const form= document.getElementByClassName('pregister_form') ;
form.addEventListerner('submit',(e)=>{
  e.preventDefault();
    registration();
  
});
// form validation

function registration()
	{
		var fname=document.getElementById("pfname").value;
	var lname= document.getElementById("plname").value;
		var telephone= document.getElementById("ptel").value;
		var Password= document.getElementById("pcode").value;					
		if(fname=='')	
		{
			alert('Please enter your name');
		}
		else if(!letters.test(name))
		{
			alert('Name field required only alphabet characters');
		}		
		else if(lname=='')
		{
			alert('Please enter the last name.');
		}
		else if(!letters.test(plname))
		{
			alert('last name field required only alphabet characters');		
		}
		else if(telephone==''|| telephone== null){
		    alert('Please enter phone number');		    
		}
		else if(telephone.value.length<10||telephone.value.length>10){
		    alert('phone number is invalid ! please enter a 10 digit phone number ')
		}
		else if(Password=='')
		{
			alert('Please enter Password');
		}	
		else if(!pwd_expression.test(Password))
		{
			alert ('Upper case, Lower case, Special character and Numeric letter are required in Password filed');
		}		else if(document.getElementById("pcode").value.length < 6)
		{
			alert ('Password minimum length is 6');
		}
		else if(document.getElementById("pcode").value.length > 12)
		{
			alert ('Password max length is 12');
		}
		else
		{				                                         alert('Pupil successfully registered');
			  
		}		
	}
	function clearFunc()
	{
		document.getElementById("pfname").value="";
		document.getElementById("plname").value="";
		document.getElementById("ptel").value="";
		document.getElementById("pcode").value="";	
	}

  