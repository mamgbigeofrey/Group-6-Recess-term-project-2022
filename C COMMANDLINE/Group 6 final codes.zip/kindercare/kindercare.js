function chkcontrol(j){
    var sum=0;
    for(var i=0; i<document.assign_form.char[].length; i++){
        if(document.assign_form.(char[])[i].checked){
            sum = sum + parseInt(document.assign_form.char[][i].value);
        }
        document.getElementById("msg").innerHTML="Sum : " + sum;
        if(sum>8){
            sum = sum - parseInt(document.assign_form.char[][j].value);
            document.assign_form.char[][j].checked=false;
            alert("You cant add more than 8 characters");
            return false;
        }
        document.getElementById("msg").innerHTML="Sum: " + sum;
    }
}

/*function checkBoxLimit(){
                var checkBoxGroup=document.forms['assign_form']['char[]'];
                var limit;
                for(var i=0;i<checkBoxGroup.length;i++){
                    checkBoxGroup[i].onclick=function(){
                        var checkedcount=0;
                        for(var i=0;i<checkBoxGroup.length;i++){
                            checkedcount +=(checkBoxGroup[i].checked) ? 1 : 0;
                        }
                        if(checkedcount>limit){
                            alert("You can only select Maximum of 8 characters.");
                            this.checked=false;
                        }
                    }
                }
            }*/

/*function checkbox(){
    var checkboxgrp=document.getElementById('character_check').getElementsByTagName("input");
    var limit = 8;
    for (var i = 0; i < checkboxgrp.length; i++){
        checkboxgrp[i].onclick = function(){
            var checkedcount = 0;
            for( var i = 0; i < checkboxgrp.length; i++){
                checkedcount += (checkboxgrp[i].checked) ? 1 : 0;
            }
            if (checkedcount > limit){
                console.log("You can only add a maximum of" + limit + "to the assignment list.");
                alert("You can only add a maximum of" + limit + "to the assignment list.");
                this.checked = false;
            }
        }
    }
}*/

let count=document.getElementById('increase_row').childNodes;


























































