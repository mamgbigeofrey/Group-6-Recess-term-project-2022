<?php
$server='localhost';
$username='root';
$password='';
$dbname='kcaa';
$dbconnect=mysqli_connect($server,$username,$password,$dbname);
?>