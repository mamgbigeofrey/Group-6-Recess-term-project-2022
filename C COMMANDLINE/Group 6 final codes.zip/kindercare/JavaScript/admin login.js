
// admin registration
const form = document.querySelector("form");

 const name=form.elements['username'];
const pswd=form.elements['usercode'];


form.addEventListerner('submit', (e)=>{
    
    e.preventDefault();
    checkinputs();
});
//validating form
function checkinputs(){
    const name= name.value.trim();
    const pswd= pswd.value.trim();
    
    if(name===''){
        seErrorFor(name,'Name should be filled');
    }
    else{
        setSuccessFor(name);
    }
    if(pswd===''){
        setErrorFor(pswd,'password should be filled');
    }
    else{
        setSuccessFor(pswd);
    }

}
 