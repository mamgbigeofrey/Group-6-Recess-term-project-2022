<!doctype html>
	<!DOCTYPE html>
	<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>KinderCare Academic Application </title>
		<link rel="stylesheet" type="text/css" href="style.css">
	</head>
	<body>
		<nav>
			<p>KINDERCARE ACADEMIC SYSTEM<p>
		</nav>
		<div class="create-container">
			<p>Teacher account creation</p>
			<form method="POST" action="createnew.php" class="createform">
				<label for="tfname">Teacher first name</label>
				<input type="text" name="tfname" id="tfname" placeholder="Enter your first name"><br>
				<label for="tlname">Teacher Last Name</label>
				<input type="text" name="tlname" id="tlname" placeholder="Enter your last name"><br>
				<label for="tusername">Teacher username</label>
				<input type="text" name="tusername" id="tusername" placeholder="Enter your username"><br>
				<label for="tcode">Teacher Code</label>
				<input type="password" name="tcode" id="tcode" placeholder="Enter your usercode"><br>
				<button>CREATE ACCOUNT</button>
			</form>
		</div>
	
	</body>
	</html>