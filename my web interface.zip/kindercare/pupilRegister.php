<!doctype html>
	<!DOCTYPE html>
	<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>KinderCare Academic Application</title>
		<link rel="stylesheet" type="text/css" href="style.css">
	</head>
	<body>
		<nav>
			<p>KINDERCARE ACADEMIC APPLICATION<p>
		</nav>

		
			<div class="register">
				<div class="register_tag"><p>Register new pupil</p></div>
				<p>Please fill in pupil information in the form to register them</p>
				<form method="POST" action="PHP/pupilRegister.php" class="sregister">
					<label for="pfname">Pupil first name</label>
					<input type="text" name="pfname" id="pfname" placeholder="Enter pupil first name e.g Agnes" required>
					<label for="plname">Pupil last name</label>
					<input type="text" name="plname" id="plname" placeholder="Enter pupil last name e.g Nabitako" required>
					<label for="ptel">Pupil phone number</label>
					<input type="tel" name="ptel" id="ptel" placeholder="Enter pupil phone number e.g 0770600452" required>
					<label for="pcode">Pupil code</label>
					<input type="password" name="pcode" id="pcode" placeholder="Enter pupil code" required>
					<button id="pregbtn" name="pregbtn">Register Pupil</button>
				</form>
			
			</div>
	</body>
	</html>