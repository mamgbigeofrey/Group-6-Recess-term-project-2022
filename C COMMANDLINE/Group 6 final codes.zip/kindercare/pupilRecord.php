
	<!DOCTYPE html>
	<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>KinderCare Academic Application</title>
		<link rel="stylesheet" type="text/css" href="style.css">
        <style>
            table{width: 80%; margin: auto;}
            td{width: 15%; background-color: aliceblue; margin-top:10px;}
            thead{color: red; text-transform: uppercase; font-size: 24px;}
            p{font-size: ;font-weight: bold; text-align: center; margin-top: 5px; margin-bottom: 5px;}
            tr{transition: 1s;}
            tr:hover{cursor: pointer;color:blue;}
            .activate{background-color: green; width: 80%; border-radius: 5px;}
            .deactivate{background-color: red; width: 80%; border-radius: 5px;}
        </style>
	</head>
	<body style="margin-top:70px;">

		<?php
		session_start();
		if(!isset($_SESSION['loggedin'])){
			header('Location: index.php');
			exit;
		}

		 ?>
        <nav class="index_nav">
            <img src="images/kindercare-logo.png">
            <h1>KinderCare Academic Application</h1>
            <ul>
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="#p">Pupil scores</a></li>
                <form action="PHP/logout.php" method="POST">
            		<li><button type="submit">Log Out</button></li>
            	</form>
            </ul>
        </nav>
        
        <p style="margin-top:100px;">This page contains the list of all registered pupils,assignment and status details.</p>
        <!--<input type="text" name="seach" placeholder="Search pupil by code">
        <button name="searched" type="submit">Search</button>-->
        <table>
            <thead>
                <td>Code</td>
                <td>FirstName</td>
                <td>LastName</td>
                <td>Phone</td>
                <td>Status</td>
            </thead>
        </table>
	
<?php
require('PHP/connection.php');
$sql="SELECT * FROM pupilRegister;";
$result=mysqli_query($dbconnect,$sql);
while ($row=mysqli_fetch_array($result)) {
	?>
	<table>
        
		<tr>
            <td><?php echo $row['CODE'];?></td>
            <td><?php echo $row['FIRSTNAME'];?></td>
            <td><?php echo $row['LASTNAME'];?></td>
            <td><?php echo $row['PHONE'];?></td>
            <td><?php
                if($row['STATUS']==1){
                    echo '<p><a href="change.php?p_id='.$row['p_id'].'&STATUS=0" class="activate">Active</a></p>';
                }
                    else{
                        echo '<p><a href="change.php?p_id='.$row['p_id'].'&STATUS=1" class="deactivate">Deactivated</a></p>';
                    }
                ?></td>
        </tr>
	<?php
	
}
?>
        
        
	</table>
        
        <p style="margin-top:100px;" id="p">Below are the records of the pupils assignments attempted</p>
         <table>
            <thead>
                <td>ID</td>
                <td>ASSIGNMENT ID</td>
                <td>PUPIL CODE</td>
                <td>ATTEMPTED ON</td>
                <td>MARKS</td>
               <!-- <td>COMMENT</td>
                <td>action</td>-->
                
            </thead>
        </table>
	
<?php
require('PHP/connection.php');
$sql="SELECT * FROM pScores;";
$result=mysqli_query($dbconnect,$sql);
while ($row=mysqli_fetch_array($result)) {
	?>
	<table>
		<tr>
            <td name="ID"><?php echo $row['id'];?></td>
            <td name="id"><?php echo $row['assign_id'];?></td>
            <td name="code"><?php echo $row['pcode'];?></td>
            <td name="time" ><?php echo $row['attempted_on'];?></td>
            <td name="score"><?php echo $row['score'];?></td>
            <!--<td ><?php// echo $row['comment'];?></td>
            <td><a href="comment.php"comment=<?//php echo $row['id'];?>>add</a></td>-->
        </tr>
    
	<?php
	
}
?>
	</table>
        
        <footer class="footer_section">
                <h3>Kindercare academic application system development by recess group G-6</h3>
            <h5>Below are our team of developers</h5>
                <div class="footer_container">
                    <div class="item_cont">
                        <img src="images/team/geof.jpg">
                        <h4>Mamgbi Geofrey</h4>
                        <p>RegNo: 20/U/22748</p>
                    </div>
                    <div class="item_cont">
                        <img src="images/team/phionah.jpg" style="width:45%;">
                        <h4>Mumararungu Phionah</h4>
                        <p>RegNo: 20/U/7749/PS</p>
                    </div>
                    <div class="item_cont">
                        <img src="images/team/mary.jpg">
                        <h4>Nakinoneka Mary Margret</h4>
                        <p>RegNo: 20/U/22748</p>
                    </div>
                    <div class="item_cont">
                        <img src="images/team/emman.jpg" >
                        <h4>Emmanuel Abdallah Odori</h4>
                        <p>RegNo: 20/U/7771/PS</p>
                    </div>
                    
                </div>
                <p>For more information/queries, you can reach us via the contacts below</p>
                    <p>Email us on:<a href="mailto:gmamgbi1999@gmail.com" style="color:blue;">gmamgbi1999@gmail.com</a><br>Or call us on:<a href="tel:+256770600452" style="color:blue;">0770600452</a></p>
                    <div class="copyright">&copy; Copyright <strong><span>Recess term Group-6 		@2022</span></strong>. All Rights Reserved
                    </div>
      <div class="credits">
        Designed with <img src="images/team/heart%20logO.png" style="width:2%; border-radius: 50%; margin-top: 10px;"> by <a href="http//www.Sensycodez.000webhostapp.com">G-6</a>
            </div>
        </footer>
	
	</body>
        <script src="jquery.js"></script>
        <script>
            function active_disactive_user(val,p_id){
                $.ajax({
                    type:'post',
                    url:'change.php',
                    data:{val:val,p_id:p_id},
                    success: function(result){
                    if(result==1){
                        $('#str' +p_id).html('Active');
                    }
                    else{
                        $('#str' +p_id ).html('Deactivated');
                    }
                }
                });
            }
        </script>
        

	
	</html>
        
        
        
        
        
        
        
        
        
        
        
        
        
        