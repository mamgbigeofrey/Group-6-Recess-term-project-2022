<!doctype html>
	<!DOCTYPE html>
	<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>KinderCare Academic Application</title>
		<link rel="stylesheet" type="text/css" href="style.css">
	</head>
	<body>
		<nav>
			<p>KINDERCARE ACADEMIC SYSTEM<p>
		</nav>
	<div class="teacher-roles">
		<div class="dashbard">
			<h6>Dashboard</h6>
			<hr><hr>
			<div class=activities>
				<h4><a href="">Register pupil</a></h4>
				<h4><a href="">Give assignment</a></h4>
				<h4><a href="">Pupil record</a></h4>
				<h4><a href="">View reports</a></h4>
			</div>
			
		</div>
		<div class="introduction">
			<h6>Welcome to KinderCare Academic Application</h6>
			<p>Thank you for using the KinderCare Academic Application</p>
			<p>Please select an action from the dashboard</p>
			<img src="images/dashboard fingure.png">

		</div>
	</div>
	</body>
	</html>