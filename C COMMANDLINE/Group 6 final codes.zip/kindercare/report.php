
	<!DOCTYPE html>
	<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>KinderCare Academic Application</title>
		<link rel="stylesheet" type="text/css" href="style.css">
		<style type="text/css">
		  table{width: 80%; margin: auto;}
            td{width: 15%; background-color: aliceblue; margin-top:10px;}
            thead{color: red; text-transform: uppercase;}
            p{font-size: ;font-weight: bold; text-align: center; margin-top: 5px; margin-bottom: 5px;}
            tr{transition: 1s;}
            tr:hover{cursor: pointer;color:blue;}
            .activate{background-color: green; width: 80%; border-radius: 5px;}
            .deactivate{background-color: red; width: 80%; border-radius: 5px;}
        </style>
	</head>
	<body>
		<nav class="index_nav">
                <img src="images/kindercare-logo.png">
				<h1>KinderCare Academic Application</h1>
				<ul>
                <li><a href="dashboard.php">Dashboard</a></li>
                <form action="PHP/logout.php" method="POST">
            		<li><button type="submit">Log Out</button></li>
            	</form>
            </ul>
			</nav>
		 <p style="margin-top:100px;" id="p">Below are the records of all the necessary reports from the school administration.</p>
         <table>
            <thead>
                <td>REPORT ID</td>
                <td>REPORT SUBJECT</td>
                <td>REPORT DESCRIPTION</td>
                <td>SENT ON</td>
            </thead>
        </table>
	
<?php
require('PHP/connection.php');
$sql="SELECT * FROM reports;";
$result=mysqli_query($dbconnect,$sql);
while ($row=mysqli_fetch_array($result)) {
	?>
	<table>
        
		<tr>
            <td><?php echo $row['id'];?></td>
            <td><?php echo $row['subject'];?></td>
            <td><?php echo $row['description'];?></td>
            <td><?php echo $row['uploaded_on'];?></td>
           
           
        </tr>
	<?php
	
}
?>
	</table>

	<footer class="footer_section">
                <h3>Kindercare academic application system development by recess group G-6</h4>
                <h5>Below are our team of developers</p>
                <div class="footer_container">
                    <div class="item_cont">
                        <img src="images/team/geof.jpg">
                        <h4>Mamgbi Geofrey</h4>
                        <p>RegNo: 20/U/22748</p>
                    </div>
                    <div class="item_cont">
                        <img src="images/team/phionah.jpg" style="width:45%;">
                        <h4>Mumararungu Phionah</h4>
                        <p>RegNo: 20/U/7749/PS</p>
                    </div>
                    <div class="item_cont">
                        <img src="images/team/mary.jpg">
                        <h4>Nakinoneka Mary Margret</h4>
                        <p>RegNo: 20/U/22748</p>
                    </div>
                    <div class="item_cont">
                        <img src="images/team/emman.jpg" >
                        <h4>Emmanuel Abdallah Odori</h4>
                        <p>RegNo: 20/U/7771/PS</p>
                    </div>
                    
                </div>
                <p>For more information/queries, you can reach us via the contacts below</p>
                    <p>Email us on:<a href="mailto:gmamgbi1999@gmail.com" style="color:blue;">gmamgbi1999@gmail.com</a><br>Or call us on:<a href="tel:+256770600452" style="color:blue;">0770600452</a></p>
                    <div class="copyright">&copy; Copyright <strong><span>Recess term Group-6 		@2022</span></strong>. All Rights Reserved
                    </div>
      <div class="credits">
        Designed with <img src="images/team/heart%20logO.png" style="width:2%; border-radius: 50%; margin-top: 10px;"> by <a href="http//www.Sensycodez.000webhostapp.com">G-6</a>
            </footer>
	
	</body>
	</html>