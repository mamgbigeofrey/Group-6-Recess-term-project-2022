
<?php

$server='localhost';
$username='root';
$password='';
$dbname='kcaa';
$table='login';

if(isset($_POST['pupil_record'])){
    
    $dbconnect=mysqli_connect($server,$username,$password,$dbname);
if(mysqli_connect_errno()){
    echo "Failed to connect to database";
}
else
{
    echo "Database connection successiful";
}

$sql=mysqli_query("SELECT * FROM pupilRegister");
while($pupillist=mysli_fetch_array($sql)){
    echo ""
}

}

?>

