<!doctype html>
	<!DOCTYPE html>
	<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>KinderCare Academic Application</title>
		<link rel="stylesheet" type="text/css" href="style.css">
	</head>
	<body>
		<nav>
			<p>KINDERCARE ACADEMIC SYSTEM<p>
		</nav>
		<div>
			<p>Welcome to KinderCare Academic Application</p>
			<p>Please log in to proceed with the system</p>
		</div>
		
		<form class="form" method="POST" action="PHP/account.php">
			<fieldset>
				<label for="username">Username:</label>
				<input type="text" name="username" placeholder="Enter username">
			</fieldset>
			<fieldset>
				<label for="usercode">User Code:</label>
				<input type="password" name="usercode" placeholder="Enter usercode">
			</fieldset>
			<button id="btnlogin">LOG IN</button>
		</form>
		<p>Have no account yet. <a href="createnew.php">Create one</a></p>
	
	</body>
	</html>