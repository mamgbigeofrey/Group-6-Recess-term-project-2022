const fname= document.getElementById('tfname');
const lname= document.getElementById('tlname');
const email= document.getElementById('temail');
const phone= document.getElementById('tphone');
const pswd= document.getElementById('tcode');
const form= document.getElementByClassName('teacher_register_form') ;
form.addEventListerner('submit',(e)=>{
  e.preventDefault();
    registration();
  
});
// form validation
function registration()
	{

		const fname= fname.value.trim();
    const lname= lname.value.trim();
    const email= email.value.trim();
    
		const phone= phone.value.trim();
    const pswd= pswd.value.trim();	
		
		
        //email id expression code
		var pwd_expression = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-])/;
		var letters = /^[A-Za-z]+$/;
		var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

		if(fname=='')
		{
			alert('Please enter first name');
		}
		else if(!letters.test(fname))
		{
			alert('Name field required only alphabet characters');
			}
				else if(lname=='')
		{
			alert('Please enter the last name.');
		}
		else if(!letters.test(lname))
		{
			alert('Last name field required only alphabet characters');
		
		}
		else if(email=='')
		{
			alert('Please enter email id');
		}
		else if (!filter.test(email))
		{
			alert('Invalid email');
		}
	
		else if(pwd=='')
		{
			alert('Please enter Password');
		}
		else if(!pwd_expression.test(pwd))
		{
			alert ('Upper case, Lower case, Special character and Numeric letter are required in Password filed');
		}
	
		else if(document.getElementById("tcode").value.length < 6)
		{
			alert ('Password minimum length is 6');
		}
		else if(document.getElementById("tcode").value.length > 12)
		{
			alert ('Password max length is 12');
		}
		else
		{				                            
               alert('Successfully registered');
			   // Redirecting to uploading assignment
window.location="";
	}
	function clearFunc()
	{
		document.getElementById("tfname").value="";
		document.getElementById("tlname").value="";
		document.getElementById("temail").value="";
		document.getElementById("tphone").value="";
		document.getElementById("tcode").value="";
	}
	