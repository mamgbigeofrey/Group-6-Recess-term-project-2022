
<!doctype html>
	<!DOCTYPE html>
	<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>KinderCare Academic Application</title>
		<link rel="stylesheet" type="text/css" href="style.css ">
	</head>
	<body>
		<nav>
			<p>KINDERCARE ACADEMIC APPLICATION<p>
		</nav>
		<div class="assignment_overlayer">
			<div class="add-characters" style="color: white;">
				<p>Please select the characters to add to the assignment list</p>
				<p>You can only add a minimum of 1 and a maximum of 8 characters to the assignment list</p>
				
				
			</div>

			<form method="POST" action="PHP/assignments.php" class="assignment-upload">
				<textarea name="more-details" placeholder="Any details acompanying the assignment? Please type it here!" rows="5"></textarea>
				<div class="character-checkbox">
					<fieldset><input type="checkbox" name="A" id="A" value="A">A</fieldset>
					<fieldset><input type="checkbox" name="B" id="B" value="B">B</fieldset>
					<fieldset><input type="checkbox" name="C" id="C" value="C">C</fieldset>
					<fieldset><input type="checkbox" name="D" id="D" value="D">D</fieldset>
					<fieldset><input type="checkbox" name="E" id="E" value="E">E</fieldset>
					<fieldset><input type="checkbox" name="F" id="F" value="F">F</fieldset>
					<fieldset><input type="checkbox" name="G" id="G" value="G">G</fieldset>
					<fieldset><input type="checkbox" name="H" id="H" value="H">H</fieldset>
					<fieldset><input type="checkbox" name="I" id="I" value="I">I</fieldset>
					<fieldset><input type="checkbox" name="J" id="J" value="J">J</fieldset>
					<fieldset><input type="checkbox" name="K" id="K" value="K">K</fieldset>
					<fieldset><input type="checkbox" name="L" id="L" value="L">L</fieldset>
					<fieldset><input type="checkbox" name="M" id="M" value="M">M</fieldset>
					<fieldset><input type="checkbox" name="N" id="N" value="N">N</fieldset>
					<fieldset><input type="checkbox" name="O" id="O" value="O">O</fieldset>
					<fieldset><input type="checkbox" name="P" id="P" value="P">P</fieldset>
					<fieldset><input type="checkbox" name="Q" id="Q" value="Q">Q</fieldset>
					<fieldset><input type="checkbox" name="R" id="R" value="R">R</fieldset>
					<fieldset><input type="checkbox" name="S" id="S" value="S">S</fieldset>
					<fieldset><input type="checkbox" name="T" id="T" value="T">T</fieldset>
					<fieldset><input type="checkbox" name="U" id="U" value="U">U</fieldset>
					<fieldset><input type="checkbox" name="V" id="V" value="V">V</fieldset>
					<fieldset><input type="checkbox" name="W" id="W" value="W">W</fieldset>
					<fieldset><input type="checkbox" name="X" id="X" value="X">X</fieldset>
					<fieldset><input type="checkbox" name="Y" id="Y" value="Y">Y</fieldset>
					<fieldset><input type="checkbox" name="Y" id="Z" value="Z">Z</fieldset>
					
				</div>
					<label for="starttime">Start Time</label>
					<input type="datetime-local" name="starttime" id="starttime">
					<label for="endtime">End Time</label>
					<input type="datetime-local" name="endtime" id="endtime">
					<button name="upload" type="submit" id="upload">Upload assignment</button>
			</form>
		
		</div>
		
	</body>
	</html>